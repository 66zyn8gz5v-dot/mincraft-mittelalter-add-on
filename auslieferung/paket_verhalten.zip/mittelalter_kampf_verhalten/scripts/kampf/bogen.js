// Langbogen: Ziehhaltung beim Spannen und schnellere, weiter fliegende Pfeile.
import { BOGEN } from "../daten/waffen.js";

/** Beim Spannen: Ziehhaltung abspielen, bis der Spieler loslässt. */
export function bogenSpannen(spieler, gegenstand) {
  if (gegenstand?.typeId !== BOGEN.id) return false;
  spieler.playAnimation("animation.mkampf.bogen.zug", {
    controller: "mkampf.bogen", stopExpression: "!q.is_using_item", blendOutTime: 0.15,
  });
  return true;
}

/**
 * Ein neuer Pfeil: Stammt er von einem Langbogen, fliegt er 30 % schneller.
 * Pfeilschaden hängt in Minecraft von der Geschwindigkeit ab – so trifft er härter und weiter.
 */
export function pfeilAbgeschossen(pfeil) {
  if (pfeil?.typeId !== "minecraft:arrow") return false;
  const schuetze = pfeil.getComponent("minecraft:projectile")?.owner;
  if (schuetze?.typeId !== "minecraft:player") return false;
  const hand = schuetze.getComponent("minecraft:equippable")?.getEquipment("Mainhand");
  if (hand?.typeId !== BOGEN.id) return false;
  const v = pfeil.getVelocity();
  const f = BOGEN.tempo - 1;
  pfeil.applyImpulse({ x: v.x * f, y: v.y * f, z: v.z * f });
  return true;
}
