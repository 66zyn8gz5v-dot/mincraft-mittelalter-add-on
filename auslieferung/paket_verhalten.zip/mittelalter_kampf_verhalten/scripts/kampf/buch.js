// Das aufgeschlagene Kampfbuch: erscheint als großes Buch vor dem Spieler, klappt auf und
// wird durch Schlagen (vor) bzw. Benutzen (zurück) mit einer Umblätter-Animation durchgeblättert.
import { world, system } from "@minecraft/server";
import { BUCH_SEITEN } from "../daten/waffen.js";
import { klang, abstand, blickXZ } from "./werkzeuge.js";

export const BUCH = "mkampf:kampfbuch_offen";
const ABSTAND = 2.1; // Blöcke vor dem Spieler
const HALB = 9; // Ticks bis die umklappende Seite gelandet ist

// Spieler-ID → { buch, doppelseite }
const offen = new Map();

function doppelseiten() {
  return Math.ceil(BUCH_SEITEN / 2);
}

function zeige(buch, links, rechts) {
  try {
    if (links !== undefined) buch.setProperty("mkampf:links", links);
    if (rechts !== undefined) buch.setProperty("mkampf:rechts", Math.min(rechts, BUCH_SEITEN - 1));
  } catch {
    // Buch verschwunden – ignorieren.
  }
}

/** Kampfbuch benutzt: öffnen bzw. wieder schließen. */
export function buchUmschalten(spieler) {
  if (offen.has(spieler.id)) {
    schliessen(spieler.id);
    return;
  }
  const kopf = spieler.getHeadLocation();
  const blick = blickXZ(spieler);
  const ort = { x: kopf.x + blick.x * ABSTAND, y: kopf.y - 1.05, z: kopf.z + blick.z * ABSTAND };
  let buch;
  try {
    buch = spieler.dimension.spawnEntity(BUCH, ort);
  } catch {
    spieler.sendMessage("§cHier ist kein Platz für das Buch.");
    return;
  }
  // Dem Spieler zugewandt (Wesen schauen mit ihrer Vorderseite in Blickrichtung).
  buch.setRotation({ x: 0, y: spieler.getRotation().y + 180 });
  zeige(buch, 0, 1);
  offen.set(spieler.id, { buch, doppelseite: 0, spieler });
  klang(spieler, "item.book.put", 1, 0.9);
  system.runTimeout(() => klang(spieler, "item.book.page_turn", 1, 0.8), 8);
}

function schliessen(spielerId) {
  const eintrag = offen.get(spielerId);
  offen.delete(spielerId);
  if (!eintrag?.buch?.isValid) return;
  try {
    eintrag.buch.playAnimation("animation.mkampf.buch.schliessen");
  } catch {
    // Nur optisch.
  }
  if (eintrag.spieler?.isValid) klang(eintrag.spieler, "item.book.put", 1, 1.1);
  system.runTimeout(() => {
    if (eintrag.buch.isValid) eintrag.buch.remove();
  }, 10);
}

function eintragFuer(spieler, buch) {
  const eintrag = offen.get(spieler.id);
  return eintrag && eintrag.buch.id === buch.id ? eintrag : undefined;
}

/** Schlag auf das Buch: eine Doppelseite weiter (auf der letzten schließt es sich). */
export function buchVor(spieler, buch) {
  const eintrag = eintragFuer(spieler, buch);
  if (!eintrag) return;
  const neu = eintrag.doppelseite + 1;
  if (neu >= doppelseiten()) {
    schliessen(spieler.id);
    return;
  }
  eintrag.doppelseite = neu;
  try {
    buch.playAnimation("animation.mkampf.buch.vor");
  } catch {
    // Nur optisch.
  }
  // Rechts erscheint sofort die neue Seite unter dem umklappenden Blatt, links nach der Landung.
  zeige(buch, undefined, neu * 2 + 1);
  system.runTimeout(() => zeige(buch, neu * 2, undefined), HALB);
  klang(spieler, "item.book.page_turn", 1, 0.9 + Math.random() * 0.2);
}

/** Benutzen des Buchs: eine Doppelseite zurück. */
export function buchZurueck(spieler, buch) {
  const eintrag = eintragFuer(spieler, buch);
  if (!eintrag || eintrag.doppelseite === 0) return;
  const neu = eintrag.doppelseite - 1;
  eintrag.doppelseite = neu;
  try {
    buch.playAnimation("animation.mkampf.buch.zurueck");
  } catch {
    // Nur optisch.
  }
  zeige(buch, neu * 2, undefined);
  system.runTimeout(() => zeige(buch, undefined, neu * 2 + 1), HALB);
  klang(spieler, "item.book.page_turn", 1, 0.8 + Math.random() * 0.2);
}

/** Schließt Bücher, deren Leser weggegangen oder verschwunden ist. */
export function buchSchleife() {
  for (const [id, eintrag] of offen) {
    const weg = !eintrag.spieler?.isValid || !eintrag.buch?.isValid ||
      eintrag.spieler.dimension.id !== eintrag.buch.dimension.id ||
      abstand(eintrag.spieler.location, eintrag.buch.location) > 7;
    if (weg) schliessen(id);
  }
}

/** Beim Laden der Welt: liegengebliebene Bücher entfernen. */
export function buecherAufraeumen() {
  for (const name of ["overworld", "nether", "the_end"]) {
    try {
      for (const buch of world.getDimension(name).getEntities({ type: BUCH })) buch.remove();
    } catch {
      // Dimension nicht geladen.
    }
  }
}
