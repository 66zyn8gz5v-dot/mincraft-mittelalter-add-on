// Das Kampfbuch als 3D-Buch. Im Inventar ist es ein flaches Item; benutzt man es auf einem Block,
// wird es auf einem Lesepult aufgestellt (bleibt stehen, jeder kann darin lesen). Benutzt man es in
// die Luft, schwebt es aufgeschlagen vor dem Spieler und klappt beim Weggehen wieder zu.
// Steuerung am Buch: Benutzen = weiterblättern, Schlagen = zurückblättern,
// Schleichen + Schlagen = zuklappen bzw. aufheben. Jedes Umblättern ist animiert.
import { world, system } from "@minecraft/server";
import { BUCH_SEITEN } from "../daten/waffen.js";
import { klang, abstand, blickXZ } from "./werkzeuge.js";
import { jetzt } from "./zustand.js";

export const BUCH = "mkampf:kampfbuch_offen";
const ABSTAND = 2.1; // Blöcke vor dem Spieler (schwebendes Buch)
const HALB = 9; // Ticks bis die umklappende Seite gelandet ist

// Schwebende Bücher: Spieler-ID → { buch, spieler }
const schwebend = new Map();
// Zuletzt aufgestelltes Buch je Spieler (verhindert, dass derselbe Klick zusätzlich ein
// schwebendes Buch öffnet): Spieler-ID → Tick
const aufgestelltBei = new Map();

function doppelseiten() {
  return Math.ceil(BUCH_SEITEN / 2);
}

function eigenschaft(buch, name, ersatz) {
  try {
    return buch.getProperty(name) ?? ersatz;
  } catch {
    return ersatz;
  }
}

function zeige(buch, links, rechts) {
  try {
    if (links !== undefined) buch.setProperty("mkampf:links", links);
    if (rechts !== undefined) buch.setProperty("mkampf:rechts", Math.min(rechts, BUCH_SEITEN - 1));
  } catch {
    // Buch verschwunden – ignorieren.
  }
}

/** Die aktuelle Doppelseite steckt im Buch selbst – so funktioniert es für jeden Leser. */
function doppelseite(buch) {
  return eigenschaft(buch, "mkampf:seite", 0);
}

function merke(buch, neu) {
  try {
    buch.setProperty("mkampf:seite", neu);
  } catch {
    // Buch verschwunden.
  }
}

function erscheinen(spieler, buch) {
  // Dem Spieler zugewandt (Wesen schauen mit ihrer Vorderseite in Blickrichtung).
  buch.setRotation({ x: 0, y: spieler.getRotation().y + 180 });
  zeige(buch, 0, 1);
  merke(buch, 0);
  klang(spieler, "item.book.put", 1, 0.9);
  system.runTimeout(() => klang(spieler, "item.book.page_turn", 1, 0.8), 8);
}

/** Kampfbuch in die Luft benutzt: schwebendes Buch öffnen bzw. wieder schließen. */
export function buchUmschalten(spieler) {
  // Derselbe Klick hat gerade ein Buch aufgestellt – dann kein zweites öffnen.
  if (jetzt() - (aufgestelltBei.get(spieler.id) ?? -99) <= 2) return;
  if (schwebend.has(spieler.id)) {
    schliessen(schwebend.get(spieler.id).buch);
    schwebend.delete(spieler.id);
    return;
  }
  const kopf = spieler.getHeadLocation();
  const blick = blickXZ(spieler);
  const ort = { x: kopf.x + blick.x * ABSTAND, y: kopf.y - 1.05, z: kopf.z + blick.z * ABSTAND };
  let buch;
  try {
    buch = spieler.dimension.spawnEntity(BUCH, ort);
  } catch {
    spieler.sendMessage("§cHier ist kein Platz für das Buch.");
    return;
  }
  erscheinen(spieler, buch);
  schwebend.set(spieler.id, { buch, spieler });
}

/**
 * Kampfbuch auf einen Block benutzt: Buch auf einem Lesepult obendrauf aufstellen.
 * Liefert true, wenn aufgestellt wurde.
 */
export function buchAufstellen(spieler, block) {
  aufgestelltBei.set(spieler.id, jetzt());
  const ort = { x: block.x + 0.5, y: block.y + 1, z: block.z + 0.5 };
  let buch;
  try {
    buch = spieler.dimension.spawnEntity(BUCH, ort);
  } catch {
    return false;
  }
  aufgestelltBei.set(spieler.id, jetzt());
  try {
    buch.setProperty("mkampf:pult", true);
  } catch {
    // Ohne Pult-Eigenschaft schwebt es eben.
  }
  erscheinen(spieler, buch);
  klang(spieler, "block.wood.place", 1, 0.8);
  spieler.sendMessage("§6Kampfbuch aufgestellt. §7Benutzen = weiterblättern · Schlagen = zurück · " +
    "Schleichen + Schlagen = aufheben");
  return true;
}

function schliessen(buch) {
  if (!buch?.isValid) return;
  try {
    buch.playAnimation("animation.mkampf.buch.schliessen");
  } catch {
    // Nur optisch.
  }
  system.runTimeout(() => {
    if (buch.isValid) buch.remove();
  }, 10);
}

/** Eine Doppelseite weiter (Benutzen). */
export function buchVor(spieler, buch) {
  const neu = doppelseite(buch) + 1;
  if (neu >= doppelseiten()) {
    klang(spieler, "item.book.put", 0.6, 1.3);
    return;
  }
  try {
    buch.playAnimation("animation.mkampf.buch.vor");
  } catch {
    // Nur optisch.
  }
  // Rechts erscheint sofort die neue Seite unter dem umklappenden Blatt, links nach der Landung.
  merke(buch, neu);
  zeige(buch, undefined, neu * 2 + 1);
  system.runTimeout(() => zeige(buch, neu * 2, undefined), HALB);
  klang(spieler, "item.book.page_turn", 1, 0.9 + Math.random() * 0.2);
}

/** Eine Doppelseite zurück (Schlagen). */
export function buchZurueck(spieler, buch) {
  const alt = doppelseite(buch);
  if (alt === 0) return;
  const neu = alt - 1;
  try {
    buch.playAnimation("animation.mkampf.buch.zurueck");
  } catch {
    // Nur optisch.
  }
  merke(buch, neu);
  zeige(buch, neu * 2, undefined);
  system.runTimeout(() => zeige(buch, undefined, neu * 2 + 1), HALB);
  klang(spieler, "item.book.page_turn", 1, 0.8 + Math.random() * 0.2);
}

/** Schleichen + Schlagen: Buch zuklappen (schwebend) bzw. vom Pult aufheben. */
export function buchZuklappen(spieler, buch) {
  for (const [id, eintrag] of schwebend) {
    if (eintrag.buch.id === buch.id) schwebend.delete(id);
  }
  klang(spieler, "item.book.put", 1, 1.1);
  schliessen(buch);
}

/** Schlag auf das Buch. */
export function buchGeschlagen(spieler, buch) {
  if (spieler.isSneaking) buchZuklappen(spieler, buch);
  else buchZurueck(spieler, buch);
}

/** Benutzen des Buchs. */
export function buchBenutzt(spieler, buch) {
  if (spieler.isSneaking) buchZurueck(spieler, buch);
  else buchVor(spieler, buch);
}

/** Schließt schwebende Bücher, deren Leser weggegangen oder verschwunden ist. */
export function buchSchleife() {
  for (const [id, eintrag] of schwebend) {
    const weg = !eintrag.spieler?.isValid || !eintrag.buch?.isValid ||
      eintrag.spieler.dimension.id !== eintrag.buch.dimension.id ||
      abstand(eintrag.spieler.location, eintrag.buch.location) > 7;
    if (weg) {
      schliessen(eintrag.buch);
      schwebend.delete(id);
    }
  }
}

/** Beim Laden der Welt: liegengebliebene schwebende Bücher entfernen (Pulte bleiben stehen). */
export function buecherAufraeumen() {
  for (const name of ["overworld", "nether", "the_end"]) {
    try {
      for (const buch of world.getDimension(name).getEntities({ type: BUCH })) {
        if (!eigenschaft(buch, "mkampf:pult", false)) buch.remove();
      }
    } catch {
      // Dimension nicht geladen.
    }
  }
}
