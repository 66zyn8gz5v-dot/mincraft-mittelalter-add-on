// Haltungen (Angriffsstellungen) und die dazugehörigen Körperposen.
import { world } from "@minecraft/server";
import { zustand, HALTUNGEN, HALTUNGS_FOLGE, melde } from "./zustand.js";
import { waffeIn, klang } from "./werkzeuge.js";

/** Wechselt Mitte → Hoch → Tief → Mitte. */
export function naechsteHaltung(spieler) {
  const z = zustand(spieler);
  const i = HALTUNGS_FOLGE.indexOf(z.haltung);
  z.haltung = HALTUNGS_FOLGE[(i + 1) % HALTUNGS_FOLGE.length];
  z.haltungsSchluessel = ""; // Pose neu abspielen
  const h = HALTUNGEN[z.haltung];
  melde(spieler, `${h.farbe}Haltung: ${h.name}`, 40);
  klang(spieler, "armor.equip_chain", 0.8, z.haltung === "hoch" ? 0.8 : z.haltung === "tief" ? 1.2 : 1.0);
  aktualisierePose(spieler);
}

/**
 * Spielt die passende Dauerpose ab, sobald sich Waffe oder Haltung ändern.
 * Die Pose endet von selbst (stop_expression), wenn keine passende Waffe mehr
 * in der Hand liegt.
 */
export function aktualisierePose(spieler) {
  const z = zustand(spieler);
  const waffe = waffeIn(spieler);
  const schluessel = waffe ? `${waffe.griff}.${z.haltung}` : "";
  if (schluessel === z.haltungsSchluessel) return;
  z.haltungsSchluessel = schluessel;
  if (!waffe) return;
  try {
    spieler.playAnimation(`animation.mkampf.haltung.${schluessel}`, {
      controller: "mkampf.haltung",
      blendOutTime: 0.25,
      stopExpression: `!q.equipped_item_any_tag('slot.weapon.mainhand', 'mkampf:griff_${waffe.griff}')`,
    });
  } catch {
    // Nur optische Wirkung.
  }
}

export function posenSchleife() {
  for (const spieler of world.getAllPlayers()) aktualisierePose(spieler);
}
