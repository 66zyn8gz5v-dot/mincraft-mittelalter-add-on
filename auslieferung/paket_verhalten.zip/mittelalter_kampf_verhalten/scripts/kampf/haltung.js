// Haltungen (Angriffsstellungen) und die dazugehörigen Körperposen.
import { world, system, EquipmentSlot } from "@minecraft/server";
import { zustand, jetzt, ladung, HALTUNGEN, HALTUNGS_FOLGE, melde } from "./zustand.js";
import { waffeIn, klang } from "./werkzeuge.js";

/** Wechselt Mitte → Hoch → Tief → Mitte. */
export function naechsteHaltung(spieler) {
  const z = zustand(spieler);
  const i = HALTUNGS_FOLGE.indexOf(z.haltung);
  z.haltung = HALTUNGS_FOLGE[(i + 1) % HALTUNGS_FOLGE.length];
  z.haltungsSchluessel = ""; // Pose neu abspielen
  const h = HALTUNGEN[z.haltung];
  melde(spieler, `${h.farbe}Haltung: ${h.name}`, 40);
  klang(spieler, "armor.equip_chain", 0.8, z.haltung === "hoch" ? 0.8 : z.haltung === "tief" ? 1.2 : 1.0);
  aktualisierePose(spieler);
}

/**
 * Spielt die passende Dauerpose der Waffe ab, sobald sich Waffe oder Haltung ändern.
 * Die Pose endet von selbst (stop_expression), wenn die Waffenart nicht mehr in
 * der Hand liegt. Während eines Angriffs oder einer Fähigkeit ruht sie.
 */
export function aktualisierePose(spieler) {
  const z = zustand(spieler);
  if (jetzt() < z.poseSperreBis) return;
  const waffe = waffeIn(spieler);
  if (!waffe && kalibrierPose(spieler, z)) return;
  // Im Block (Schleichen gehalten) wird die Waffe quer gehalten, beim Aufladen zurückgezogen.
  const blockt = waffe && z.block && spieler.isSneaking;
  const art = blockt ? (ladung(spieler) >= 0.3 ? "laden" : "block") : "";
  const schluessel = waffe ? (art ? `${art}.${waffe.artId}` : `haltung.${waffe.artId}.${z.haltung}`) : "";
  if (schluessel === z.haltungsSchluessel) return;
  z.haltungsSchluessel = schluessel;
  if (!waffe) return;
  const stopp = `!q.equipped_item_any_tag('slot.weapon.mainhand', 'mkampf:${waffe.artId}')`;
  try {
    spieler.playAnimation(`animation.mkampf.${schluessel}`, {
      controller: "mkampf.haltung",
      blendOutTime: art ? 0.1 : 0.2,
      stopExpression: art ? `!q.is_sneaking || ${stopp}` : stopp,
    });
  } catch {
    // Nur optische Wirkung.
  }
}

/** Testpose für die Kalibrierstäbe (rechter Arm gerade nach vorn). */
function kalibrierPose(spieler, z) {
  let typ;
  try {
    typ = spieler.getComponent("minecraft:equippable")?.getEquipment(EquipmentSlot.Mainhand)?.typeId;
  } catch {
    return false;
  }
  if (!typ?.startsWith("mkampf:kalibrierung")) return false;
  if (z.haltungsSchluessel === "kalibrierung") return true;
  z.haltungsSchluessel = "kalibrierung";
  try {
    spieler.playAnimation("animation.mkampf.kalibrierung.pose", {
      controller: "mkampf.haltung",
      blendOutTime: 0.1,
      stopExpression: "!q.equipped_item_any_tag('slot.weapon.mainhand', 'mkampf:kalibrierung')",
    });
  } catch {
    // Nur optische Wirkung.
  }
  return true;
}

/**
 * Spielt eine Ganzkörper-Bewegung (Angriff/Fähigkeit) anstelle der Haltung ab.
 * Danach kehrt die Haltungspose automatisch zurück.
 */
export function ganzkoerper(spieler, name, dauer) {
  const z = zustand(spieler);
  const ticks = Math.ceil(dauer * 20);
  z.poseSperreBis = jetzt() + ticks;
  z.haltungsSchluessel = ""; // danach Pose neu abspielen
  try {
    spieler.playAnimation(name, { controller: "mkampf.haltung", blendOutTime: 0.12 });
  } catch {
    // Nur optische Wirkung.
  }
  // Direkt nach dem Ende in die Haltung zurückkehren (ohne Lücke bis zur nächsten Schleife).
  system.runTimeout(() => {
    if (spieler.isValid) aktualisierePose(spieler);
  }, ticks);
}

export function posenSchleife() {
  for (const spieler of world.getAllPlayers()) aktualisierePose(spieler);
}
