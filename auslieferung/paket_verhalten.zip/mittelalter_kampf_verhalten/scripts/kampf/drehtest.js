// Drehtest für die Waffenhaltung: Sitzt die Waffe im Spiel falsch herum, kann der Spieler im
// Duell-Menü (Schleichen + Kampfbuch) Zusatzdrehungen um den Griff durchschalten. Die gewählte
// Nummer bleibt gespeichert und wird nach Tod/Neubeitritt wieder angewendet. Wer die passende
// Nummer meldet, bekommt sie in der nächsten Version fest eingebaut.
import { DREH_VARIANTEN } from "../daten/waffen.js";

const EIGENSCHAFT = "mkampf:dreh";

export const DREH_NAMEN = [
  "Normal (wie ausgeliefert)",
  "Um 180° gekippt (vorn/hinten)",
  "Um 180° gekippt (seitlich)",
  "Um die eigene Achse gedreht",
  "90° nach vorn gekippt",
  "90° nach hinten gekippt",
  "90° zur Seite gekippt",
  "90° zur anderen Seite gekippt",
];

export function aktuelleDrehung(spieler) {
  const n = Number(spieler.getDynamicProperty(EIGENSCHAFT) ?? 0);
  return Number.isFinite(n) ? n % DREH_VARIANTEN : 0;
}

/** Spielt die Animation ab, die im Client die Variable v.mkampf_dreh setzt. */
export function drehungAnwenden(spieler) {
  const n = aktuelleDrehung(spieler);
  try {
    spieler.playAnimation(`animation.mkampf.dreh.${n}`, { controller: "mkampf.dreh" });
  } catch {
    // Nur optische Wirkung.
  }
}

/** Schaltet zur nächsten Variante weiter und meldet die Nummer. */
export function naechsteDrehung(spieler) {
  const n = (aktuelleDrehung(spieler) + 1) % DREH_VARIANTEN;
  spieler.setDynamicProperty(EIGENSCHAFT, n);
  drehungAnwenden(spieler);
  spieler.sendMessage(`§6Waffenhaltung: Variante ${n} §7– ${DREH_NAMEN[n] ?? ""}. ` +
    "§7Passt es? Dann diese Nummer melden. Nochmal = nächste Variante.");
}
