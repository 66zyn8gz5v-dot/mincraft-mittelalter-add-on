// 1v1-Duelle: Herausforderung, Countdown, Siegerehrung und Statistik.
import { world } from "@minecraft/server";
import { MessageFormData } from "@minecraft/server-ui";
import { zustand, jetzt, MAX_AUSDAUER } from "./zustand.js";
import { heile, effekt, klang, spaeter } from "./werkzeuge.js";

// Laufende Duelle: Spieler-ID → { gegner: Spieler-ID, start: Tick }
const duelle = new Map();

export function imDuell(spieler) {
  return duelle.has(spieler.id);
}

function spielerMitId(id) {
  return world.getAllPlayers().find((p) => p.id === id);
}

export function statistik(spieler) {
  return {
    siege: spieler.getDynamicProperty("mkampf:siege") ?? 0,
    niederlagen: spieler.getDynamicProperty("mkampf:niederlagen") ?? 0,
  };
}

/** Schickt eine Herausforderung an einen anderen Spieler. */
export async function herausfordern(von, an) {
  if (imDuell(von) || imDuell(an)) {
    von.sendMessage("§cEiner von euch kämpft bereits ein Duell.");
    return;
  }
  von.sendMessage(`§7Herausforderung an §e${an.name}§7 gesendet …`);
  const form = new MessageFormData()
    .title("§l⚔ Duell-Herausforderung")
    .body(`§e${von.name}§r fordert dich zu einem Duell auf Leben und Tod heraus!\n\n` +
      "Beide Kämpfer werden voll geheilt. Nach dem Countdown beginnt der Kampf.")
    .button1("§cAblehnen")
    .button2("§aAnnehmen");
  try {
    const antwort = await form.show(an);
    if (antwort.canceled || antwort.selection !== 1) {
      von.sendMessage(`§c${an.name} hat das Duell abgelehnt.`);
      return;
    }
  } catch {
    return;
  }
  if (!von.isValid || !an.isValid) return;
  starte(von, an);
}

function vorbereiten(spieler) {
  const hp = spieler.getComponent("minecraft:health");
  if (hp) heile(spieler, hp.effectiveMax);
  const z = zustand(spieler);
  z.ausdauer = MAX_AUSDAUER;
  z.erschoepft = false;
  z.kombo = 0;
  z.faehigkeitBereit = 0;
  effekt(spieler, "saturation", 20, 10, false);
  // Während des Countdowns kann niemand angreifen oder laufen.
  effekt(spieler, "slowness", 60, 10, false);
  effekt(spieler, "weakness", 60, 10, false);
  effekt(spieler, "resistance", 60, 10, false);
}

function starte(a, b) {
  const t = jetzt();
  duelle.set(a.id, { gegner: b.id, start: t });
  duelle.set(b.id, { gegner: a.id, start: t });
  for (const p of [a, b]) vorbereiten(p);
  world.sendMessage(`§6⚔ Duell: §e${a.name} §7gegen §e${b.name}§7!`);
  [3, 2, 1].forEach((zahl, i) => {
    spaeter(i * 20, () => {
      for (const p of [a, b]) {
        if (!p.isValid) continue;
        p.onScreenDisplay.setTitle(`§6${zahl}`, {
          fadeInDuration: 0, stayDuration: 16, fadeOutDuration: 4, subtitle: "§7Mach dich bereit …",
        });
        klang(p, "note.pling", 1, 0.8 + i * 0.2);
      }
    });
  });
  spaeter(60, () => {
    for (const p of [a, b]) {
      if (!p.isValid) continue;
      p.onScreenDisplay.setTitle("§c§lKAMPF!", {
        fadeInDuration: 0, stayDuration: 20, fadeOutDuration: 10, subtitle: "§7Möge der Bessere siegen",
      });
      klang(p, "raid.horn", 0.6, 1.2);
    }
  });
}

function beende(siegerId, verliererId, grund) {
  duelle.delete(siegerId);
  duelle.delete(verliererId);
  const sieger = spielerMitId(siegerId);
  const verlierer = spielerMitId(verliererId);
  if (sieger) {
    sieger.setDynamicProperty("mkampf:siege", statistik(sieger).siege + 1);
    sieger.onScreenDisplay.setTitle("§6§lSIEG!", {
      fadeInDuration: 5, stayDuration: 50, fadeOutDuration: 15, subtitle: `§7${grund}`,
    });
    klang(sieger, "random.totem", 0.6, 1.2);
    const hp = sieger.getComponent("minecraft:health");
    if (hp) heile(sieger, hp.effectiveMax);
  }
  if (verlierer) {
    verlierer.setDynamicProperty("mkampf:niederlagen", statistik(verlierer).niederlagen + 1);
    verlierer.onScreenDisplay.setTitle("§4§lNIEDERLAGE", {
      fadeInDuration: 5, stayDuration: 50, fadeOutDuration: 15, subtitle: `§7${grund}`,
    });
  }
  world.sendMessage(`§6⚔ §e${sieger?.name ?? "?"} §7hat das Duell gegen §e${verlierer?.name ?? "?"} §7gewonnen!`);
}

export function beiTod(ereignis) {
  const tot = ereignis.deadEntity;
  if (tot.typeId !== "minecraft:player") return;
  const duell = duelle.get(tot.id);
  if (!duell) return;
  beende(duell.gegner, tot.id, "Im ehrenvollen Zweikampf");
}

export function beiVerlassen(spielerId) {
  const duell = duelle.get(spielerId);
  if (duell) beende(duell.gegner, spielerId, "Der Gegner ist geflohen");
}
