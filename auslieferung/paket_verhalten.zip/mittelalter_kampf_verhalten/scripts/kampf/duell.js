// 1v1-Duelle: Herausforderung, Best-of-3-Runden im Kampfring, Countdown, Siegerehrung, Statistik.
//
// Ablauf: Nach der Annahme entsteht zwischen beiden Kämpfern ein Kampfring (Partikelkreis). Eine
// Runde verliert, wer unter 5 Lebenspunkte fällt (oder stirbt) – niemand verliert dabei Gegenstände.
// Danach werden beide geheilt, an ihre Startpunkte im Ring gesetzt und die nächste Runde beginnt mit
// Countdown. Wer zuerst zwei Runden gewinnt, gewinnt das Duell. Wer den Ring verlässt, wird
// zurückgestoßen.
import { world, ItemStack, ItemLockMode } from "@minecraft/server";
import { ARTEN } from "../daten/waffen.js";
import { MessageFormData } from "@minecraft/server-ui";
import { zustand, jetzt, MAX_AUSDAUER } from "./zustand.js";
import { heile, effekt, klang, spaeter, stoss, richtungXZ, abstand } from "./werkzeuge.js";

export const SIEGE_NOETIG = 2; // Best of 3
export const RING_RADIUS = 7; // Blöcke um die Mitte
const START_ABSTAND = 3; // Blöcke von der Mitte bis zum Startpunkt
const RUNDE_VERLOREN_BEI = 5; // Lebenspunkte
const COUNTDOWN = 60; // Ticks
const KIT_NAME = "§6Duell-Waffe"; // Kennzeichen der geliehenen Waffe (wird am Ende eingesammelt)

// Laufende Duelle: Spieler-ID → gemeinsamer Eintrag
// { a, b: Spieler-IDs, siege: {id: n}, runde, mitte, kampfAb: Tick, wartet: bool }
const duelle = new Map();

export function imDuell(spieler) {
  return duelle.has(spieler.id);
}

export function duellVon(spieler) {
  return duelle.get(spieler.id);
}

function spielerMitId(id) {
  return world.getAllPlayers().find((p) => p.id === id);
}

const RANGLISTE = "mkampf:rangliste";

/** Rangliste aller Duellanten der Welt: [{name, siege, niederlagen}], beste zuerst. */
export function rangliste() {
  let daten = {};
  try {
    daten = JSON.parse(world.getDynamicProperty(RANGLISTE) ?? "{}");
  } catch {
    daten = {};
  }
  return Object.entries(daten)
    .map(([name, w]) => ({ name, siege: w[0], niederlagen: w[1] }))
    .sort((x, y) => y.siege - x.siege || x.niederlagen - y.niederlagen);
}

function ranglisteEintragen(sieger, verlierer) {
  let daten = {};
  try {
    daten = JSON.parse(world.getDynamicProperty(RANGLISTE) ?? "{}");
  } catch {
    daten = {};
  }
  if (sieger) (daten[sieger.name] ??= [0, 0])[0]++;
  if (verlierer) (daten[verlierer.name] ??= [0, 0])[1]++;
  try {
    world.setDynamicProperty(RANGLISTE, JSON.stringify(daten));
  } catch {
    // Speichern nicht möglich – Rangliste bleibt unverändert.
  }
}

export function statistik(spieler) {
  return {
    siege: spieler.getDynamicProperty("mkampf:siege") ?? 0,
    niederlagen: spieler.getDynamicProperty("mkampf:niederlagen") ?? 0,
  };
}

function titel(spieler, text, unten, dauer = 30) {
  try {
    spieler.onScreenDisplay.setTitle(text, {
      fadeInDuration: 0, stayDuration: dauer, fadeOutDuration: 8, subtitle: unten,
    });
  } catch {
    // Spieler lädt gerade.
  }
}

/** Schickt eine Herausforderung an einen anderen Spieler. */
export async function herausfordern(von, an, kit = null) {
  if (imDuell(von) || imDuell(an)) {
    von.sendMessage("§cEiner von euch kämpft bereits ein Duell.");
    return;
  }
  von.sendMessage(`§7Herausforderung an §e${an.name}§7 gesendet …`);
  const form = new MessageFormData()
    .title("§l⚔ Duell-Herausforderung")
    .body(`§e${von.name}§r fordert dich zum Duell heraus!\n\n` +
      `Best of 3 im Kampfring: Wer zuerst ${SIEGE_NOETIG} Runden gewinnt, siegt. ` +
      "Eine Runde ist verloren, wenn die Lebenspunkte fast aufgebraucht sind – niemand verliert Gegenstände." +
      (kit ? `\n\n§6Gleiche Waffen:§r Beide kämpfen mit ${ARTEN[kit]?.name ?? kit} (Eisen).` : ""))
    .button1("§cAblehnen")
    .button2("§aAnnehmen");
  try {
    const antwort = await form.show(an);
    if (antwort.canceled || antwort.selection !== 1) {
      von.sendMessage(`§c${an.name} hat das Duell abgelehnt.`);
      return;
    }
  } catch {
    return;
  }
  if (!von.isValid || !an.isValid) return;
  duellStarten(von, an, kit);
}

function vorbereiten(spieler) {
  const hp = spieler.getComponent("minecraft:health");
  if (hp) heile(spieler, hp.effectiveMax);
  const z = zustand(spieler);
  z.ausdauer = MAX_AUSDAUER;
  z.erschoepft = false;
  z.kombo = 0;
  z.faehigkeitBereit = 0;
  effekt(spieler, "saturation", 20, 10, false);
  // Während des Countdowns kann niemand angreifen oder laufen.
  effekt(spieler, "slowness", COUNTDOWN, 10, false);
  effekt(spieler, "weakness", COUNTDOWN, 10, false);
  effekt(spieler, "resistance", COUNTDOWN, 10, false);
}

/** Startpunkte gegenüber im Ring; beide schauen sich an. */
function aufstellen(duell, a, b) {
  const m = duell.mitte;
  const r = duell.achse;
  const orte = [
    [a, { x: m.x - r.x * START_ABSTAND, y: m.y, z: m.z - r.z * START_ABSTAND }],
    [b, { x: m.x + r.x * START_ABSTAND, y: m.y, z: m.z + r.z * START_ABSTAND }],
  ];
  for (const [p, ort] of orte) {
    try {
      p.teleport(ort, { facingLocation: { x: m.x, y: m.y + 1.6, z: m.z } });
    } catch {
      // Ort blockiert – dann bleibt der Kämpfer, wo er ist.
    }
  }
}

/**
 * Kit: Beide bekommen für das Duell dieselbe Waffe (Eisen) geliehen – faire Bedingungen.
 * Die Leihwaffe lässt sich nicht fallen lassen, bleibt beim Tod erhalten und wird am Ende eingesammelt.
 */
export function kitAusgeben(spieler, kit) {
  const inventar = spieler.getComponent("minecraft:inventory")?.container;
  if (!inventar) return;
  const item = new ItemStack(`mkampf:${kit}_eisen`);
  item.nameTag = KIT_NAME;
  item.lockMode = ItemLockMode.inventory;
  item.keepOnDeath = true;
  let platz;
  for (let i = 0; i < 9; i++) {
    if (!inventar.getItem(i)) {
      platz = i;
      break;
    }
  }
  platz ??= inventar.firstEmptySlot?.();
  if (platz === undefined) {
    spieler.sendMessage("§cKein Platz im Inventar für die Duell-Waffe – du kämpfst mit deiner eigenen.");
    return;
  }
  inventar.setItem(platz, item);
  if (platz < 9) {
    try {
      spieler.selectedSlotIndex = platz;
    } catch {
      // Auswahl nicht möglich – Waffe liegt trotzdem bereit.
    }
  }
}

/** Sammelt die geliehene Duell-Waffe wieder ein. */
export function kitEinsammeln(spieler) {
  const inventar = spieler.getComponent("minecraft:inventory")?.container;
  if (!inventar) return;
  for (let i = 0; i < (inventar.size ?? 36); i++) {
    if (inventar.getItem(i)?.nameTag === KIT_NAME) inventar.setItem(i, undefined);
  }
}

export function duellStarten(a, b, kit = null) {
  const mitte = {
    x: (a.location.x + b.location.x) / 2, y: Math.max(a.location.y, b.location.y),
    z: (a.location.z + b.location.z) / 2,
  };
  const duell = {
    a: a.id, b: b.id, siege: { [a.id]: 0, [b.id]: 0 }, runde: 0, mitte,
    achse: richtungXZ(a.location, b.location), kampfAb: 0, wartet: false, kit,
  };
  if (kit) for (const p of [a, b]) kitAusgeben(p, kit);
  duelle.set(a.id, duell);
  duelle.set(b.id, duell);
  world.sendMessage(`§6⚔ Duell (Best of 3): §e${a.name} §7gegen §e${b.name}§7!`);
  naechsteRunde(duell);
}

function naechsteRunde(duell) {
  const a = spielerMitId(duell.a);
  const b = spielerMitId(duell.b);
  if (!a || !b) return;
  duell.runde++;
  duell.wartet = false;
  duell.kampfAb = jetzt() + COUNTDOWN;
  aufstellen(duell, a, b);
  for (const p of [a, b]) vorbereiten(p);
  const stand = `§e${duell.siege[duell.a]} : ${duell.siege[duell.b]}`;
  [3, 2, 1].forEach((zahl, i) => {
    spaeter(i * 20, () => {
      for (const p of [a, b]) {
        if (!p.isValid) continue;
        titel(p, `§6Runde ${duell.runde}`, `§7${zahl} … §8|§r ${stand}`, 16);
        klang(p, "note.pling", 1, 0.8 + i * 0.2);
      }
    });
  });
  spaeter(COUNTDOWN, () => {
    for (const p of [a, b]) {
      if (!p.isValid) continue;
      titel(p, "§c§lKAMPF!", "§7Möge der Bessere siegen", 20);
      klang(p, "raid.horn", 0.6, 1.2);
    }
  });
}

/** Eine Runde ist entschieden. */
function rundeVerloren(verliererId, grund, tot = false) {
  const duell = duelle.get(verliererId);
  if (!duell || duell.wartet) return;
  const siegerId = duell.a === verliererId ? duell.b : duell.a;
  duell.siege[siegerId]++;
  duell.wartet = true;
  if (duell.siege[siegerId] >= SIEGE_NOETIG) {
    beende(siegerId, verliererId, grund);
    return;
  }
  const sieger = spielerMitId(siegerId);
  const verlierer = spielerMitId(verliererId);
  const stand = `${duell.siege[duell.a]} : ${duell.siege[duell.b]}`;
  for (const p of [sieger, verlierer]) {
    if (!p) continue;
    const gewonnen = p.id === siegerId;
    titel(p, gewonnen ? "§a§lRunde gewonnen" : "§c§lRunde verloren", `§7Stand §e${stand}`, 40);
    klang(p, gewonnen ? "random.levelup" : "note.bass", 0.6, gewonnen ? 1.4 : 0.6);
    const hp = p.getComponent("minecraft:health");
    if (hp && hp.currentValue > 0) heile(p, hp.effectiveMax);
    effekt(p, "resistance", 60, 10, false);
  }
  // Nach einem echten Tod startet die Runde erst, wenn der Verlierer wieder da ist (beiWiedereintritt).
  if (!tot) spaeter(50, () => naechsteRunde(duell));
}

function beende(siegerId, verliererId, grund) {
  const duell = duelle.get(siegerId) ?? duelle.get(verliererId);
  duelle.delete(siegerId);
  duelle.delete(verliererId);
  const sieger = spielerMitId(siegerId);
  const verlierer = spielerMitId(verliererId);
  if (duell?.kit) for (const p of [sieger, verlierer]) if (p) kitEinsammeln(p);
  if (sieger) {
    sieger.setDynamicProperty("mkampf:siege", statistik(sieger).siege + 1);
    titel(sieger, "§6§lSIEG!", `§7${grund}`, 50);
    klang(sieger, "random.totem", 0.6, 1.2);
    const hp = sieger.getComponent("minecraft:health");
    if (hp) heile(sieger, hp.effectiveMax);
  }
  if (verlierer) {
    verlierer.setDynamicProperty("mkampf:niederlagen", statistik(verlierer).niederlagen + 1);
    titel(verlierer, "§4§lNIEDERLAGE", `§7${grund}`, 50);
    const hp = verlierer.getComponent("minecraft:health");
    if (hp && hp.currentValue > 0) heile(verlierer, hp.effectiveMax);
  }
  ranglisteEintragen(sieger, verlierer);
  world.sendMessage(`§6⚔ §e${sieger?.name ?? "?"} §7hat das Duell gegen §e${verlierer?.name ?? "?"} §7gewonnen!`);
}

/** Nach jedem Treffer: Fällt ein Duellant zu tief, ist die Runde verloren (bevor er stirbt). */
export function duellTreffer(ereignis) {
  const opfer = ereignis.hurtEntity;
  if (opfer?.typeId !== "minecraft:player" || !imDuell(opfer)) return;
  const hp = opfer.getComponent("minecraft:health");
  if (hp && hp.currentValue > 0 && hp.currentValue <= RUNDE_VERLOREN_BEI) {
    rundeVerloren(opfer.id, "Im ehrenvollen Zweikampf");
  }
}

export function beiTod(ereignis) {
  const tot = ereignis.deadEntity;
  if (tot.typeId !== "minecraft:player") return;
  if (!imDuell(tot)) return;
  rundeVerloren(tot.id, "Im ehrenvollen Zweikampf", true);
}

/** Wiedereintritt nach dem Tod: Läuft das Duell noch, beginnt die nächste Runde. */
export function beiWiedereintritt(spieler) {
  const duell = duelle.get(spieler.id);
  if (duell?.wartet) spaeter(10, () => naechsteRunde(duell));
}

export function beiVerlassen(spielerId) {
  const duell = duelle.get(spielerId);
  if (!duell) return;
  const siegerId = duell.a === spielerId ? duell.b : duell.a;
  beende(siegerId, spielerId, "Der Gegner ist geflohen");
}

/** Alle 10 Ticks: Kampfring zeichnen und Duellanten im Ring halten. */
export function ringSchleife() {
  const erledigt = new Set();
  for (const duell of duelle.values()) {
    if (erledigt.has(duell)) continue;
    erledigt.add(duell);
    const a = spielerMitId(duell.a);
    const b = spielerMitId(duell.b);
    if (!a || !b) continue;
    const m = duell.mitte;
    // Ring aus 24 Funken auf Bodenhöhe.
    for (let i = 0; i < 24; i++) {
      const w = (i / 24) * Math.PI * 2;
      try {
        a.dimension.spawnParticle("minecraft:basic_flame_particle",
          { x: m.x + Math.cos(w) * RING_RADIUS, y: m.y + 0.2, z: m.z + Math.sin(w) * RING_RADIUS });
      } catch {
        // Bereich nicht geladen.
      }
    }
    for (const p of [a, b]) {
      const d = abstand(p.location, m);
      if (d > RING_RADIUS) {
        stoss(p, richtungXZ(p.location, m), 0.8, 0.2);
        try {
          p.onScreenDisplay.setActionBar("§c⚠ Zurück in den Kampfring!");
        } catch {
          // Spieler lädt gerade.
        }
      }
    }
  }
}
