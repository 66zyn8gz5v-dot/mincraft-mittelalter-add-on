// Kampfzustand je Spieler (nur im Speicher, wird beim Verlassen gelöscht).
import { system } from "@minecraft/server";

export const MAX_AUSDAUER = 100;

// Haltungen: Schadensfaktor, Ausdauerfaktor, Schutz und Paradefenster.
export const HALTUNGEN = {
  mitte: { name: "Mitte", farbe: "§e", schaden: 1.0, kosten: 1.0, schutz: 1.0, parade: 5 },
  hoch: { name: "Hoch", farbe: "§c", schaden: 1.2, kosten: 1.25, schutz: 1.1, parade: 3 },
  tief: { name: "Tief", farbe: "§b", schaden: 0.85, kosten: 0.9, schutz: 0.8, parade: 9 },
};
export const HALTUNGS_FOLGE = ["mitte", "hoch", "tief"];

const zustaende = new Map();

export function zustand(spieler) {
  let z = zustaende.get(spieler.id);
  if (!z) {
    z = {
      ausdauer: MAX_AUSDAUER,
      letzteAnstrengung: 0, // Tick der letzten Ausdauer-Ausgabe
      haltung: "mitte",
      haltungsSchluessel: "", // aktuell gespielte Posen-Animation
      kombo: 0,
      komboZiel: "",
      komboZeit: 0,
      angriffsSchritt: 0, // wechselt die Angriffsanimation (1-2-3)
      technik: "", // Name der aktuellen Technik (z. B. „Oberhau“)
      letzterSchwung: -1000, // Tick des letzten Schwungs (Angriffstempo)
      aufladung: 1, // Aufladung beim letzten Schwung (0 … 1)
      paradeBis: 0, // Tick, bis zu dem eine Parade aktiv ist
      paradeSperre: 0,
      riposteBis: 0,
      ausweichenBis: 0, // Unverwundbarkeit beim Ausweichen
      ausweichSperre: 0,
      letztesSchleichen: 0,
      faehigkeitBereit: 0, // Tick, ab dem die Fähigkeit wieder bereit ist
      buff: null, // { art, bis } – Verstärkung für den nächsten Treffer
      erschoepft: false,
      betaeubtBis: 0,
      meldung: "", // kurze Zusatzanzeige in der Aktionsleiste
      meldungBis: 0,
    };
    zustaende.set(spieler.id, z);
  }
  return z;
}

export function vergessen(spielerId) {
  zustaende.delete(spielerId);
}

export function jetzt() {
  return system.currentTick;
}

/** Verbraucht Ausdauer. Liefert false, wenn der Spieler erschöpft ist. */
export function verbrauche(spieler, menge) {
  const z = zustand(spieler);
  z.letzteAnstrengung = jetzt();
  if (z.ausdauer < menge) {
    z.ausdauer = 0;
    z.erschoepft = true;
    return false;
  }
  z.ausdauer -= menge;
  if (z.ausdauer <= 0) z.erschoepft = true;
  return true;
}

export function melde(spieler, text, ticks = 30) {
  const z = zustand(spieler);
  z.meldung = text;
  z.meldungBis = jetzt() + ticks;
}
