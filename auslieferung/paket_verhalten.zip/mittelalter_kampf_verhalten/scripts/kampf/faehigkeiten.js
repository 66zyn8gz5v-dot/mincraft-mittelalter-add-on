// Spezialfähigkeiten der Waffen (Rechtsklick). Schleichen + Rechtsklick wechselt die Haltung.
import { zustand, jetzt, verbrauche, melde } from "./zustand.js";
import {
  waffeIn, blickXZ, richtungXZ, abstand, stoss, effekt, klang, partikel, animation,
  gegnerImUmkreis, gegnerImKegel, zielImBlick, faehigkeitsSchaden, wahrerSchaden, heile, spaeter,
} from "./werkzeuge.js";
import { naechsteHaltung } from "./haltung.js";
import { blute, brecheSchild } from "./schaden.js";

const KOSTEN = 30;

export function gegenstandBenutzt(spieler, item) {
  const waffe = waffeIn(spieler);
  if (!waffe || waffe.id !== item?.typeId) return;
  if (spieler.isSneaking) {
    naechsteHaltung(spieler);
    return;
  }
  if (!waffe.faehigkeit) return; // Speer: Ansturm übernimmt das Spiel selbst
  const z = zustand(spieler);
  const t = jetzt();
  if (t < z.faehigkeitBereit) {
    melde(spieler, `§7${waffe.art.faehigkeitName}: noch ${Math.ceil((z.faehigkeitBereit - t) / 20)} s`, 20);
    return;
  }
  if (!verbrauche(spieler, KOSTEN)) {
    melde(spieler, "§cZu erschöpft!", 25);
    return;
  }
  const ausfuehren = FAEHIGKEITEN[waffe.faehigkeit];
  if (!ausfuehren) return;
  const erfolg = ausfuehren(spieler, waffe);
  if (erfolg === false) {
    // Kein Ziel gefunden: Ausdauer teilweise zurück, kurze Sperre.
    z.ausdauer = Math.min(100, z.ausdauer + KOSTEN * 0.7);
    z.faehigkeitBereit = t + 20;
    melde(spieler, "§7Kein Ziel in Reichweite", 20);
    return;
  }
  z.faehigkeitBereit = t + waffe.fcd;
  melde(spieler, `§6✦ ${waffe.art.faehigkeitName}`, 30);
}

function sprungNachVorn(spieler, staerke, hoch = 0.12) {
  stoss(spieler, blickXZ(spieler), staerke, hoch);
}

const FAEHIGKEITEN = {
  schattenschritt(spieler) {
    const z = zustand(spieler);
    sprungNachVorn(spieler, 2.4, 0.1);
    z.ausweichenBis = jetzt() + 6;
    z.buff = { art: "rueckenstich", bis: jetzt() + 50 };
    effekt(spieler, "invisibility", 20, 0, false);
    partikel(spieler, "minecraft:large_explosion", 0.8);
    klang(spieler, "mob.endermen.portal", 0.6, 1.6);
    animation(spieler, "animation.mkampf.sonder.sprung", "mkampf.angriff");
  },

  halbschwert(spieler) {
    sprungNachVorn(spieler, 1.3);
    zustand(spieler).buff = { art: "stoss", bis: jetzt() + 30 };
    klang(spieler, "item.trident.riptide_1", 0.5, 1.5);
    animation(spieler, "animation.mkampf.sonder.sprung", "mkampf.angriff");
  },

  wirbelhieb(spieler, waffe) {
    animation(spieler, "animation.mkampf.sonder.wirbel", "mkampf.angriff", 0.05);
    klang(spieler, "mob.warden.attack", 0.6, 1.1);
    spaeter(6, () => {
      for (const e of gegnerImUmkreis(spieler, 3.2)) {
        faehigkeitsSchaden(e, waffe.schaden * 0.8, spieler);
        stoss(e, richtungXZ(spieler.location, e.location), 0.9, 0.25);
        partikel(e, "minecraft:critical_hit_emitter");
      }
      partikel(spieler, "minecraft:huge_explosion_emitter", 0.5);
    });
  },

  riposte(spieler) {
    const z = zustand(spieler);
    z.riposteBis = jetzt() + 20;
    klang(spieler, "armor.equip_iron", 1, 1.5);
    animation(spieler, "animation.mkampf.sonder.riposte", "mkampf.angriff");
  },

  klingenwirbel(spieler) {
    const ziel = zielImBlick(spieler, 3.5);
    if (!ziel) return false;
    animation(spieler, "animation.mkampf.angriff.saebel.1", "mkampf.angriff", 0.05);
    for (let i = 0; i < 3; i++) {
      spaeter(i * 5, () => {
        if (!ziel.isValid) return;
        wahrerSchaden(ziel, 2, spieler);
        blute(ziel, spieler, 1);
        klang(ziel, "item.trident.hit", 0.6, 1.4 + i * 0.2);
        partikel(ziel, "minecraft:critical_hit_emitter");
        animation(spieler, `animation.mkampf.angriff.saebel.${(i % 2) + 1}`, "mkampf.angriff", 0.05);
      });
    }
  },

  schildbrecher(spieler, waffe) {
    const ziel = zielImBlick(spieler, 3.5);
    if (!ziel) return false;
    animation(spieler, "animation.mkampf.angriff.streitaxt.3", "mkampf.angriff", 0.05);
    spaeter(6, () => {
      faehigkeitsSchaden(ziel, waffe.schaden * 0.7, spieler);
      brecheSchild(ziel, 100);
      effekt(ziel, "weakness", 60, 0, false);
      stoss(ziel, richtungXZ(spieler.location, ziel.location), 0.6, 0.2);
    });
  },

  erdbeben(spieler, waffe) {
    animation(spieler, "animation.mkampf.sonder.erdbeben", "mkampf.angriff", 0.05);
    spaeter(9, () => {
      klang(spieler, "random.explode", 0.6, 1.3);
      klang(spieler, "random.anvil_land", 1, 0.5);
      partikel(spieler, "minecraft:huge_explosion_emitter", 0.1);
      for (const e of gegnerImUmkreis(spieler, 4.5)) {
        const nah = 1 - Math.min(1, abstand(e.location, spieler.location) / 4.5);
        faehigkeitsSchaden(e, waffe.schaden * (0.4 + 0.4 * nah), spieler);
        stoss(e, richtungXZ(spieler.location, e.location), 0.5, 0.65);
        effekt(e, "slowness", 60, 1, false);
      }
    });
  },

  schaedelspalter(spieler) {
    zustand(spieler).buff = { art: "schaedel", bis: jetzt() + 80 };
    klang(spieler, "armor.equip_netherite", 1, 0.7);
    partikel(spieler, "minecraft:villager_angry", 2.1);
  },

  kettenwurf(spieler, waffe) {
    const ziel = zielImBlick(spieler, 7);
    if (!ziel) return false;
    animation(spieler, "animation.mkampf.sonder.zug", "mkampf.angriff", 0.05);
    const d = abstand(spieler.location, ziel.location);
    stoss(ziel, richtungXZ(ziel.location, spieler.location), Math.min(2.2, d * 0.3), 0.3);
    faehigkeitsSchaden(ziel, Math.max(2, waffe.schaden * 0.3), spieler);
    klang(ziel, "item.chain.place", 1, 0.7);
    klang(spieler, "mob.warden.attack", 0.4, 1.8);
  },

  sichelzug(spieler, waffe) {
    const ziel = zielImBlick(spieler, 5);
    if (!ziel) return false;
    animation(spieler, "animation.mkampf.sonder.zug", "mkampf.angriff", 0.05);
    const d = abstand(spieler.location, ziel.location);
    stoss(ziel, richtungXZ(ziel.location, spieler.location), Math.min(1.8, d * 0.3), 0.2);
    effekt(ziel, "slowness", 40, 1, false);
    faehigkeitsSchaden(ziel, waffe.schaden * 0.45, spieler);
    klang(ziel, "item.trident.hit", 1, 0.8);
  },

  seelenernte(spieler, waffe) {
    animation(spieler, "animation.mkampf.angriff.kriegssense.2", "mkampf.angriff", 0.05);
    klang(spieler, "mob.wither.shoot", 0.3, 1.6);
    spaeter(5, () => {
      const ziele = gegnerImKegel(spieler, 4.2, 0.2);
      for (const e of ziele) {
        faehigkeitsSchaden(e, waffe.schaden * 0.65, spieler);
        partikel(e, "minecraft:soul_particle");
        heile(spieler, 1.5);
      }
    });
  },
};
