// Das Kampfbuch: Anleitung, Waffenkunde, Duell-Herausforderung und Statistik.
import { world } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { ARTEN, WAFFEN } from "../daten/waffen.js";
import { herausfordern, statistik } from "./duell.js";

const STEUERUNG =
  "§l§6Angreifen§r\n" +
  "Jede Waffe hat ihr eigenes Tempo. Schwere Waffen treffen hart, brauchen aber länger. " +
  "Die §f⚔-Leiste§r zeigt, ob deine Waffe wieder voll aufgeladen ist – wer zu früh zuschlägt, " +
  "trifft nur schwach und bricht seine Kombo. " +
  "Jeder Schlag kostet §aAusdauer§r – bei leerer Leiste bist du §cerschöpft§r und schlägst schwach zu.\n\n" +
  "§l§6Kombos§r\n" +
  "Triffst du denselben Gegner mehrmals schnell hintereinander, wird jeder dritte Treffer ein " +
  "§dFinisher§r mit Bonusschaden. Wirst du getroffen, bricht deine Kombo.\n\n" +
  "§l§6Haltungen§r (Schleichen + Rechtsklick)\n" +
  "§eMitte§r – ausgewogen\n§cHoch§r – +20 % Schaden, kostet mehr Ausdauer, kurzes Paradefenster\n" +
  "§bTief§r – −15 % Schaden, −20 % erlittener Schaden, großes Paradefenster, schnellere Erholung\n\n" +
  "§l§6Parade§r (Schleichen antippen)\n" +
  "Kurz vor dem gegnerischen Treffer antippen: Schaden wird abgewehrt, der Angreifer gerät aus dem Gleichgewicht.\n\n" +
  "§l§6Ausweichen§r (Schleichen doppelt antippen + Laufrichtung)\n" +
  "Schneller Seitschritt mit kurzer Unverwundbarkeit.\n\n" +
  "§l§6Spezialfähigkeit§r (Rechtsklick)\n" +
  "Jede Waffenart hat eine eigene Fähigkeit mit Abklingzeit.\n\n" +
  "§l§6Rückenstich§r\nTreffer von hinten verursachen Bonusschaden – Dolche besonders viel.\n\n" +
  "§l§6Zweihandwaffen§r\nLangschwert, Zweihänder, Streitaxt, Kriegshammer und alle Stangenwaffen " +
  "brauchen beide Hände: Solange du sie hältst, ist die Nebenhand gesperrt (§c✖§r). " +
  "Der Gegenstand dort wandert ins Inventar und kommt beim Wegstecken zurück.";

const STUFEN = ["eisen", "gold", "diamant", "netherit"];
const STUFEN_NAME = { eisen: "Eisen", gold: "Gold", diamant: "Diamant", netherit: "Netherit" };
const GRIFF_NAME = { einhand: "Einhändig", zweihand: "Zweihändig", stange: "Stangenwaffe" };

export async function oeffneKampfbuch(spieler) {
  const s = statistik(spieler);
  const form = new ActionFormData()
    .title("§l⚔ Kampfbuch")
    .body(`Willkommen, Streiter!\n§7Siege: §a${s.siege}§7 · Niederlagen: §c${s.niederlagen}`)
    .button("Kampfsystem & Steuerung", "textures/items/book_writable")
    .button("Waffenkunde", "textures/items/mkampf/langschwert_eisen")
    .button("Duell herausfordern", "textures/items/mkampf/doppeldolche_eisen");
  const antwort = await form.show(spieler);
  if (antwort.canceled) return;
  if (antwort.selection === 0) await text(spieler, "Kampfsystem", STEUERUNG);
  if (antwort.selection === 1) await waffenkunde(spieler);
  if (antwort.selection === 2) await duellMenue(spieler);
}

async function text(spieler, titel, inhalt) {
  const form = new ActionFormData().title(titel).body(inhalt).button("Zurück");
  const antwort = await form.show(spieler);
  if (!antwort.canceled) await oeffneKampfbuch(spieler);
}

async function waffenkunde(spieler) {
  const ids = Object.keys(ARTEN);
  const form = new ActionFormData().title("Waffenkunde").body("Wähle eine Waffe:");
  for (const id of ids) form.button(ARTEN[id].name, `textures/items/mkampf/${id}_eisen`);
  const antwort = await form.show(spieler);
  if (antwort.canceled) return;
  const id = ids[antwort.selection];
  const art = ARTEN[id];
  let tabelle = "";
  for (const st of STUFEN) {
    const w = WAFFEN[`mkampf:${id}_${st}`];
    tabelle += `§7${STUFEN_NAME[st]}: §fSchaden ${w.schaden + 1} · Tempo ${w.cd.toFixed(2)} s\n`;
  }
  const inhalt =
    `§l${art.name}§r  §8(${GRIFF_NAME[art.griff]})\n\n` +
    `§6Reichweite:§r ${art.reichweite} Blöcke\n` +
    `§6Passiv:§r ${art.passiv}\n` +
    `§6Fähigkeit – ${art.faehigkeitName}:§r ${art.faehigkeitText}\n` +
    `§6Ausdauer pro Schlag:§r ${WAFFEN[`mkampf:${id}_eisen`].kosten}\n` +
    `§6Kombo-Techniken:§r ${art.angriffe.join(" → ")}\n` +
    (art.zweihaendig ? "§c✖ Zweihändig – sperrt die Nebenhand§r\n" : "") +
    `\n${tabelle}`;
  await text(spieler, art.name, inhalt);
}

async function duellMenue(spieler) {
  const andere = world.getAllPlayers().filter((p) => p.id !== spieler.id);
  if (andere.length === 0) {
    await text(spieler, "Duell", "§7Es ist gerade kein anderer Spieler online.");
    return;
  }
  const form = new ActionFormData().title("Duell herausfordern").body("Wen forderst du heraus?");
  for (const p of andere) form.button(p.name);
  const antwort = await form.show(spieler);
  if (antwort.canceled) return;
  const gegner = andere[antwort.selection];
  if (gegner?.isValid) herausfordern(spieler, gegner);
}
