// Das Kampfbuch: Anleitung, Waffenkunde, Duell-Herausforderung und Statistik.
import { world } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { ARTEN, WAFFEN, VERSION } from "../daten/waffen.js";
import { aktuelleDrehung, naechsteDrehung, DREH_NAMEN } from "./drehtest.js";
import { herausfordern, statistik, rangliste } from "./duell.js";

const STUFEN = ["eisen", "gold", "diamant", "netherit"];
const STUFEN_NAME = { eisen: "Eisen", gold: "Gold", diamant: "Diamant", netherit: "Netherit" };
const GRIFF_NAME = { einhand: "Einhändig", zweihand: "Zweihändig", stange: "Stangenwaffe" };

/** Duell-Menü (Schleichen + Kampfbuch). Die Anleitung steht im aufklappbaren Buch. */
export async function oeffneKampfbuch(spieler) {
  const s = statistik(spieler);
  const form = new ActionFormData()
    .title(`§l⚔ Duell §r§8v${VERSION}`)
    .body(`§7Siege: §a${s.siege}§7 · Niederlagen: §c${s.niederlagen}\n\n` +
      "§fDie ganze Anleitung findest du im Kampfbuch – einfach benutzen, ohne zu schleichen.\n\n" +
      `§8Verhalten v${VERSION} – der Name des Kampfbuchs zeigt die Bilder-Version.`)
    .button("Duell herausfordern", "textures/items/mkampf/doppeldolche_eisen")
    .button("Waffenkunde (kurz)", "textures/items/mkampf/langschwert_eisen")
    .button(`Waffenhaltung testen\n§8Variante ${aktuelleDrehung(spieler)}: ${DREH_NAMEN[aktuelleDrehung(spieler)]}`,
      "textures/items/mkampf/rapier_eisen")
    .button("Rangliste", "textures/items/mkampf/kriegshammer_gold");
  const antwort = await form.show(spieler);
  if (antwort.canceled) return;
  if (antwort.selection === 0) await duellMenue(spieler);
  if (antwort.selection === 1) await waffenkunde(spieler);
  if (antwort.selection === 2) naechsteDrehung(spieler);
  if (antwort.selection === 3) await zeigeRangliste(spieler);
}

async function zeigeRangliste(spieler) {
  const liste = rangliste().slice(0, 10);
  const zeilen = liste.length
    ? liste.map((e, i) => `${i === 0 ? "§6" : i < 3 ? "§e" : "§f"}${i + 1}. ${e.name} §7– §a${e.siege} Siege §7/ §c${e.niederlagen}`)
    : ["§7Noch keine Duelle ausgetragen."];
  await text(spieler, "§l⚔ Rangliste", zeilen.join("\n"));
}

async function text(spieler, titel, inhalt) {
  const form = new ActionFormData().title(titel).body(inhalt).button("Zurück");
  const antwort = await form.show(spieler);
  if (!antwort.canceled) await oeffneKampfbuch(spieler);
}

async function waffenkunde(spieler) {
  const ids = Object.keys(ARTEN);
  const form = new ActionFormData().title("Waffenkunde").body("Wähle eine Waffe:");
  for (const id of ids) form.button(ARTEN[id].name, `textures/items/mkampf/${id}_eisen`);
  const antwort = await form.show(spieler);
  if (antwort.canceled) return;
  const id = ids[antwort.selection];
  const art = ARTEN[id];
  let tabelle = "";
  for (const st of STUFEN) {
    const w = WAFFEN[`mkampf:${id}_${st}`];
    tabelle += `§7${STUFEN_NAME[st]}: §fSchaden ${w.schaden + 1} · Tempo ${w.cd.toFixed(2)} s\n`;
  }
  const inhalt =
    `§l${art.name}§r  §8(${GRIFF_NAME[art.griff]})\n\n` +
    `§6Reichweite:§r ${art.reichweite} Blöcke\n` +
    `§6Passiv:§r ${art.passiv}\n` +
    `§6Fähigkeit – ${art.faehigkeitName}:§r ${art.faehigkeitText}\n` +
    `§6Ausdauer pro Schlag:§r ${WAFFEN[`mkampf:${id}_eisen`].kosten}\n` +
    `§6Kombo-Techniken:§r ${art.angriffe.join(" → ")}\n` +
    (art.zweihaendig ? "§c✖ Zweihändig – sperrt die Nebenhand§r\n" : "") +
    `\n${tabelle}`;
  await text(spieler, art.name, inhalt);
}

async function duellMenue(spieler) {
  const andere = world.getAllPlayers().filter((p) => p.id !== spieler.id);
  if (andere.length === 0) {
    await text(spieler, "Duell", "§7Es ist gerade kein anderer Spieler online.");
    return;
  }
  const form = new ActionFormData().title("Duell herausfordern").body("Wen forderst du heraus?");
  for (const p of andere) form.button(p.name);
  const antwort = await form.show(spieler);
  if (antwort.canceled) return;
  const gegner = andere[antwort.selection];
  if (!gegner?.isValid) return;
  // Waffenwahl: eigene Ausrüstung oder beide mit derselben Leihwaffe (faire Bedingungen).
  const ids = Object.keys(ARTEN);
  const wahl = new ActionFormData().title("Waffen für das Duell")
    .body("Kämpft ihr mit euren eigenen Waffen oder bekommt ihr beide dieselbe (Eisen)?")
    .button("Eigene Waffen");
  for (const id of ids) wahl.button(ARTEN[id].name, `textures/items/mkampf/${id}_eisen`);
  const kitAntwort = await wahl.show(spieler);
  if (kitAntwort.canceled) return;
  const kit = kitAntwort.selection === 0 ? null : ids[kitAntwort.selection - 1];
  herausfordern(spieler, gegner, kit);
}
