// Übungspuppe: zum Trainieren ohne Gegner. Zeigt nach jedem Treffer Schaden, Kombo und Technik
// über dem Kopf an, wackelt nach und heilt sich nach kurzer Pause wieder voll.
import { world, ItemStack } from "@minecraft/server";
import { zustand, jetzt } from "./zustand.js";
import { klang, spaeter } from "./werkzeuge.js";

export const PUPPE = "mkampf:uebungspuppe";
export const PUPPEN_ITEM = "mkampf:uebungspuppe_item";
const PAUSE = 60; // Ticks ohne Treffer, bis die Puppe sich heilt und die Anzeige zurücksetzt

// Puppen-ID → { start: Lebenspunkte zu Beginn der Serie, summe, letzter, treffer, bis }
const serien = new Map();

function leben(puppe) {
  try {
    return puppe.getComponent("minecraft:health");
  } catch {
    return undefined;
  }
}

/** Puppe auf einem Block aufstellen (dem Spieler zugewandt). */
export function puppeAufstellen(spieler, block) {
  const ort = { x: block.x + 0.5, y: block.y + 1, z: block.z + 0.5 };
  let puppe;
  try {
    puppe = spieler.dimension.spawnEntity(PUPPE, ort);
  } catch {
    return false;
  }
  try {
    puppe.setRotation({ x: 0, y: spieler.getRotation().y + 180 });
    puppe.nameTag = "§7Übungspuppe";
  } catch {
    // Nur Kosmetik.
  }
  klang(spieler, "dig.grass", 1, 0.8);
  spieler.sendMessage("§6Übungspuppe aufgestellt. §7Schlagen = trainieren · Schleichen + Schlagen = abbauen");
  return true;
}

/** Nach einem Treffer auf die Puppe (läuft nach der Schadensberechnung). */
export function puppeGetroffen(ereignis) {
  const puppe = ereignis.hurtEntity;
  if (puppe?.typeId !== PUPPE) return;
  const hp = leben(puppe);
  if (!hp) return;
  const t = jetzt();
  let serie = serien.get(puppe.id);
  if (!serie || t > serie.bis) serie = { start: hp.effectiveMax, treffer: 0 };
  serie.bis = t + PAUSE;
  serie.treffer++;
  serien.set(puppe.id, serie);
  try {
    puppe.playAnimation("animation.mkampf.puppe.wackeln");
  } catch {
    // Nur optisch.
  }
  // Die Anzeige erst einen Tick später setzen: dann sind alle Zusatzschäden eingerechnet.
  spaeter(1, () => {
    if (!puppe.isValid) return;
    const jetztHp = leben(puppe)?.currentValue ?? hp.effectiveMax;
    const summe = serie.start - jetztHp;
    const letzter = summe - (serie.vorher ?? 0);
    serie.vorher = summe;
    const angreifer = ereignis.damageSource?.damagingEntity;
    const z = angreifer?.typeId === "minecraft:player" ? zustand(angreifer) : null;
    const extra = [];
    if (z?.kombo >= 2) extra.push(`§dKombo x${z.kombo}`);
    if (z?.technik && t - z.letzterSchwung <= 4) extra.push(`§e${z.technik}`);
    if (z?.schlagArt === "kraft" && t - z.letzterSchwung <= 4) extra.push("§6Kraftschlag");
    try {
      puppe.nameTag = `§c-${letzter.toFixed(1)} §7(gesamt ${summe.toFixed(1)}, ${serie.treffer} Treffer)` +
        (extra.length ? `\n${extra.join(" §7· ")}` : "");
    } catch {
      // Nur Anzeige.
    }
  });
}

/** Schleichen + Schlagen baut die Puppe ab; liefert true, wenn abgebaut wurde. */
export function puppeAbbauen(spieler, puppe) {
  if (puppe?.typeId !== PUPPE || !spieler.isSneaking) return false;
  try {
    puppe.dimension.spawnItem(new ItemStack(PUPPEN_ITEM), puppe.location);
  } catch {
    // Ohne Rückgabe.
  }
  serien.delete(puppe.id);
  puppe.remove();
  klang(spieler, "dig.grass", 1, 1.2);
  return true;
}

/** Alle 10 Ticks: Puppen nach der Pause wieder heilen und Anzeige zurücksetzen. */
export function puppenSchleife() {
  const t = jetzt();
  for (const [id, serie] of serien) {
    if (t <= serie.bis) continue;
    serien.delete(id);
    for (const name of ["overworld", "nether", "the_end"]) {
      try {
        const puppe = world.getDimension(name).getEntities({ type: PUPPE }).find((e) => e.id === id);
        if (!puppe) continue;
        const hp = leben(puppe);
        hp?.resetToMaxValue?.();
        puppe.nameTag = "§7Übungspuppe";
      } catch {
        // Dimension nicht geladen.
      }
    }
  }
}

/** Verbraucht ein Puppen-Item aus der ausgewählten Hand (nicht im Kreativmodus). */
export function puppenItemVerbrauchen(spieler) {
  try {
    if (spieler.getGameMode?.() === "Creative" || spieler.getGameMode?.() === "creative") return;
    const inventar = spieler.getComponent("minecraft:inventory")?.container;
    const platz = spieler.selectedSlotIndex;
    const item = inventar?.getItem(platz);
    if (item?.typeId !== PUPPEN_ITEM) return;
    if (item.amount > 1) {
      item.amount -= 1;
      inventar.setItem(platz, item);
    } else {
      inventar.setItem(platz, undefined);
    }
  } catch {
    // Verbrauch nicht möglich – Puppe steht trotzdem.
  }
}
