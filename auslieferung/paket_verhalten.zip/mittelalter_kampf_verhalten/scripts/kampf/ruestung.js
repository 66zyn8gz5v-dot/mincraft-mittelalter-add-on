// Set-Boni der Rüstungen, die über die Zeit wirken (Segen, Drachenblut).
import { world } from "@minecraft/server";
import { vollesSet, effekt } from "./werkzeuge.js";

/** Restdauer eines Effekts in Ticks (0, wenn er fehlt oder die Abfrage nicht geht). */
function restdauer(spieler, name) {
  try {
    return spieler.getEffect?.(name)?.duration ?? 0;
  } catch {
    return 0;
  }
}

let takt = 0;
const heldenmutBereit = new Map(); // Spieler-ID → Takt, ab dem Heldenmut wieder wirken darf

function leben(spieler) {
  try {
    return spieler.getComponent("minecraft:health")?.currentValue ?? 20;
  } catch {
    return 20;
  }
}

/** Wird jede Sekunde aufgerufen. */
export function ruestungsSchleife() {
  takt++;
  for (const spieler of world.getAllPlayers()) {
    // Drachenblut (voller Drachenstahl): zwei Herzen mehr und Feuerschutz, ohne Partikel.
    if (vollesSet(spieler, "drachen")) {
      if (restdauer(spieler, "health_boost") < 200) effekt(spieler, "health_boost", 600, 0, false);
      if (restdauer(spieler, "fire_resistance") < 200) effekt(spieler, "fire_resistance", 600, 0, false);
    }
    // Segen (volle Paladinrüstung): alle 8 Sekunden ein kurzer Schub Regeneration.
    if (vollesSet(spieler, "paladin") && takt % 8 === 0) effekt(spieler, "regeneration", 50, 0, false);
    // Rudel (volle Wolfsrüstung): Schnelligkeit.
    if (vollesSet(spieler, "wolf") && restdauer(spieler, "speed") < 60) effekt(spieler, "speed", 200, 0, false);
    // Heldenmut (volle Heldenrüstung): bei 3 Herzen oder weniger Stärke und Widerstand, alle 60 s.
    if (vollesSet(spieler, "held") && leben(spieler) <= 6 && takt >= (heldenmutBereit.get(spieler.id) ?? 0)) {
      effekt(spieler, "strength", 120, 0, true);
      effekt(spieler, "resistance", 120, 0, true);
      heldenmutBereit.set(spieler.id, takt + 60);
      try {
        spieler.onScreenDisplay?.setActionBar("§6§lHeldenmut!");
      } catch {
        // Anzeige ist nicht wichtig.
      }
    }
  }
}
