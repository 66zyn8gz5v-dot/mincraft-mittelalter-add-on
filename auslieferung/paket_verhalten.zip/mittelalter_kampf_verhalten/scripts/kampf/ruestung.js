// Set-Boni der Rüstungen, die über die Zeit wirken (Segen, Drachenblut).
import { world } from "@minecraft/server";
import { vollesSet, effekt } from "./werkzeuge.js";

/** Restdauer eines Effekts in Ticks (0, wenn er fehlt oder die Abfrage nicht geht). */
function restdauer(spieler, name) {
  try {
    return spieler.getEffect?.(name)?.duration ?? 0;
  } catch {
    return 0;
  }
}

let takt = 0;

/** Wird jede Sekunde aufgerufen. */
export function ruestungsSchleife() {
  takt++;
  for (const spieler of world.getAllPlayers()) {
    // Drachenblut (voller Drachenstahl): zwei Herzen mehr und Feuerschutz, ohne Partikel.
    if (vollesSet(spieler, "drachen")) {
      if (restdauer(spieler, "health_boost") < 200) effekt(spieler, "health_boost", 600, 0, false);
      if (restdauer(spieler, "fire_resistance") < 200) effekt(spieler, "fire_resistance", 600, 0, false);
    }
    // Segen (volle Paladinrüstung): alle 8 Sekunden ein kurzer Schub Regeneration.
    if (vollesSet(spieler, "paladin") && takt % 8 === 0) effekt(spieler, "regeneration", 50, 0, false);
  }
}
