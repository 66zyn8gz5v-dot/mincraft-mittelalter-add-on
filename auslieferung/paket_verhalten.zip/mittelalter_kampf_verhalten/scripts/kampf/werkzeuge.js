// Allgemeine Hilfsfunktionen: Vektoren, Schaden, Heilung, Effekte, Zielsuche.
import { system, EquipmentSlot, EntityDamageCause } from "@minecraft/server";
import { WAFFEN, ARTEN, RUESTUNG } from "../daten/waffen.js";

// Schaden aus unserem eigenen System (Fähigkeiten, wahrer Schaden) wird hier
// je Ziel mit dem Tick vermerkt. After-Events kommen erst am Tick-Ende an,
// deshalb reicht ein einfacher Merker während des Aufrufs nicht aus.
const interneTreffer = new Map();

function markiereIntern(opfer) {
  const liste = interneTreffer.get(opfer.id) ?? [];
  liste.push(system.currentTick);
  interneTreffer.set(opfer.id, liste);
}

/** Stammt dieser Schaden aus dem eigenen System? Verbraucht die Markierung. */
export function istIntern(opfer) {
  const liste = interneTreffer.get(opfer.id);
  if (!liste) return false;
  const t = system.currentTick;
  while (liste.length && t - liste[0] > 2) liste.shift();
  const intern = liste.length > 0;
  if (intern) liste.shift();
  if (!liste.length) interneTreffer.delete(opfer.id);
  return intern;
}

// ---------------------------------------------------------------------------
// Waffen
// ---------------------------------------------------------------------------

/** Liefert die Waffendaten des Gegenstands in der gegebenen Hand (oder undefined). */
export function waffeIn(entity, slot = EquipmentSlot.Mainhand) {
  try {
    const ausruestung = entity.getComponent("minecraft:equippable");
    const item = ausruestung?.getEquipment(slot);
    if (!item) return undefined;
    const daten = WAFFEN[item.typeId];
    if (!daten) return undefined;
    return { ...daten, id: item.typeId, art: ARTEN[daten.art], artId: daten.art };
  } catch {
    return undefined;
  }
}

/** Prüft, ob die Nebenhand einen Schild trägt. */
export function hatSchild(entity) {
  try {
    const ausruestung = entity.getComponent("minecraft:equippable");
    return (
      ausruestung?.getEquipment(EquipmentSlot.Offhand)?.typeId === "minecraft:shield" ||
      ausruestung?.getEquipment(EquipmentSlot.Mainhand)?.typeId === "minecraft:shield"
    );
  } catch {
    return false;
  }
}

/** In Bedrock blockt man mit Schild durch Schleichen. */
export function blocktMitSchild(entity) {
  return entity.isSneaking === true && hatSchild(entity);
}

// ---------------------------------------------------------------------------
// Vektoren
// ---------------------------------------------------------------------------

export function abstand(a, b) {
  const dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

/** Waagerechte Einheitsrichtung von a nach b. */
export function richtungXZ(von, nach) {
  const dx = nach.x - von.x, dz = nach.z - von.z;
  const l = Math.sqrt(dx * dx + dz * dz) || 1;
  return { x: dx / l, z: dz / l };
}

/** Waagerechte Blickrichtung. */
export function blickXZ(entity) {
  const v = entity.getViewDirection();
  const l = Math.sqrt(v.x * v.x + v.z * v.z) || 1;
  return { x: v.x / l, z: v.z / l };
}

/** Steht der Angreifer hinter dem Opfer? (Rückenstich) */
export function istHinter(angreifer, opfer) {
  const blick = blickXZ(opfer);
  const zumAngreifer = richtungXZ(opfer.location, angreifer.location);
  return blick.x * zumAngreifer.x + blick.z * zumAngreifer.z < -0.35;
}

// ---------------------------------------------------------------------------
// Leben und Schaden
// ---------------------------------------------------------------------------

function lebenKomponente(entity) {
  try {
    return entity.getComponent("minecraft:health");
  } catch {
    return undefined;
  }
}

export function leben(entity) {
  return lebenKomponente(entity)?.currentValue ?? 0;
}

/** Heilt ein Wesen (z. B. Rückerstattung bei Parade oder Lebensraub). */
export function heile(entity, menge) {
  const hp = lebenKomponente(entity);
  if (!hp || !entity.isValid || menge <= 0) return;
  hp.setCurrentValue(Math.min(hp.effectiveMax, hp.currentValue + menge));
}

/**
 * Wahrer Schaden: ignoriert Rüstung und Unverwundbarkeitsfenster.
 * Tödliche Treffer laufen über applyDamage, damit der Kill korrekt zählt.
 */
export function wahrerSchaden(opfer, menge, angreifer) {
  const hp = lebenKomponente(opfer);
  if (!hp || !opfer.isValid || menge <= 0) return;
  const rest = hp.currentValue - menge;
  if (rest > 0.5) {
    hp.setCurrentValue(rest);
    return;
  }
  markiereIntern(opfer);
  try {
    opfer.applyDamage(hp.currentValue + 50, {
      cause: EntityDamageCause.override,
      ...(angreifer?.isValid ? { damagingEntity: angreifer } : {}),
    });
  } catch {
    hp.setCurrentValue(0);
  }
}

/** Normaler Schaden aus einer Fähigkeit (Rüstung zählt, löst Rückstoß aus). */
export function faehigkeitsSchaden(opfer, menge, angreifer) {
  if (!opfer.isValid) return;
  markiereIntern(opfer);
  try {
    opfer.applyDamage(menge, { cause: EntityDamageCause.entityAttack, damagingEntity: angreifer });
  } catch {
    // Manche Wesen (z. B. Rüstungsständer) nehmen keinen Schaden – ignorieren.
  }
}

// ---------------------------------------------------------------------------
// Effekte, Klänge, Partikel
// ---------------------------------------------------------------------------

export function effekt(entity, name, ticks, staerke = 0, partikel = true) {
  try {
    entity.addEffect(name, ticks, { amplifier: staerke, showParticles: partikel });
  } catch {
    // Wesen ohne Effekt-Unterstützung überspringen.
  }
}

export function klang(entity, id, lautstaerke = 1, tonhoehe = 1) {
  try {
    entity.dimension.playSound(id, entity.location, { volume: lautstaerke, pitch: tonhoehe });
  } catch {
    // Unbekannter Klang – still ignorieren.
  }
}

export function partikel(entity, id, hoehe = 1) {
  try {
    const l = entity.location;
    entity.dimension.spawnParticle(id, { x: l.x, y: l.y + hoehe, z: l.z });
  } catch {
    // Unbekannter Partikel – still ignorieren.
  }
}

/** Partikel an der Stelle, an der zwei Kämpfer aufeinandertreffen (zwischen ihnen, Brusthöhe). */
export function partikelZwischen(a, b, id, hoehe = 1.35) {
  try {
    const la = a.location, lb = b.location;
    const r = richtungXZ(la, lb);
    b.dimension.spawnParticle(id, { x: lb.x - r.x * 0.45, y: lb.y + hoehe, z: lb.z - r.z * 0.45 });
  } catch {
    // Unbekannter Partikel – still ignorieren.
  }
}

/** Eigener Klang mit leicht zufälliger Tonhöhe (klingt bei Wiederholung natürlicher). */
export function eigenklang(entity, id, lautstaerke = 1, tonhoehe = 1) {
  klang(entity, id, lautstaerke, tonhoehe * (0.93 + Math.random() * 0.14));
}

export function stoss(entity, richtung, staerke, hoch) {
  try {
    entity.applyKnockback({ x: richtung.x * staerke, z: richtung.z * staerke }, hoch);
  } catch {
    // Manche Wesen lassen sich nicht stoßen.
  }
}

export function animation(entity, name, controller, blend = 0.12) {
  try {
    entity.playAnimation(name, { controller, blendOutTime: blend });
  } catch {
    // Nur optische Wirkung.
  }
}

// ---------------------------------------------------------------------------
// Zielsuche
// ---------------------------------------------------------------------------

const IGNORIERT = new Set([
  "minecraft:item", "minecraft:xp_orb", "minecraft:arrow", "minecraft:armor_stand",
  "minecraft:painting", "minecraft:leash_knot", "minecraft:snowball", "minecraft:egg",
  "minecraft:ender_pearl", "minecraft:fireworks_rocket", "minecraft:thrown_trident",
]);

function lebendig(e) {
  return e.isValid && !IGNORIERT.has(e.typeId) && e.getComponent("minecraft:health") !== undefined;
}

/** Alle lebenden Wesen im Umkreis (ohne den Nutzer selbst). */
export function gegnerImUmkreis(nutzer, radius) {
  return nutzer.dimension
    .getEntities({ location: nutzer.location, maxDistance: radius })
    .filter((e) => e.id !== nutzer.id && lebendig(e));
}

/** Wesen im Kegel vor dem Nutzer (Winkel als Kosinus-Grenze). */
export function gegnerImKegel(nutzer, radius, kosGrenze = 0.4) {
  const blick = blickXZ(nutzer);
  return gegnerImUmkreis(nutzer, radius).filter((e) => {
    const r = richtungXZ(nutzer.location, e.location);
    return blick.x * r.x + blick.z * r.z >= kosGrenze;
  });
}

/** Erstes Wesen in Blickrichtung. */
export function zielImBlick(nutzer, reichweite) {
  try {
    const treffer = nutzer.getEntitiesFromViewDirection({ maxDistance: reichweite });
    for (const t of treffer) if (lebendig(t.entity)) return t.entity;
  } catch {
    // Kein Ziel.
  }
  // Etwas großzügiger: schmaler Kegel vor dem Spieler.
  const kandidaten = gegnerImKegel(nutzer, reichweite, 0.85);
  kandidaten.sort((a, b) => abstand(a.location, nutzer.location) - abstand(b.location, nutzer.location));
  return kandidaten[0];
}

export function spaeter(ticks, funktion) {
  system.runTimeout(() => {
    try {
      funktion();
    } catch {
      // Ziel könnte inzwischen verschwunden sein.
    }
  }, ticks);
}

const RUESTUNGS_SLOTS = ["Head", "Chest", "Legs", "Feet"];

/**
 * Wirkung der getragenen Mittelalter-Rüstung: Summe je Teil (z. B. Plattenrüstung macht langsamer,
 * Gambeson lässt Ausdauer schneller zurückkehren). Ergebnis: { tempo, erholung, teile: {set: n} }.
 */
export function ruestungsWirkung(spieler) {
  const wirkung = { tempo: 0, erholung: 0, teile: {} };
  let ausruestung;
  try {
    ausruestung = spieler.getComponent("minecraft:equippable");
  } catch {
    return wirkung;
  }
  if (!ausruestung) return wirkung;
  for (const slot of RUESTUNGS_SLOTS) {
    let typ;
    try {
      typ = ausruestung.getEquipment(EquipmentSlot[slot] ?? slot)?.typeId;
    } catch {
      continue;
    }
    for (const [set, werte] of Object.entries(RUESTUNG)) {
      if (typ?.startsWith(`mkampf:${set}_`)) {
        wirkung.tempo += werte.tempo;
        wirkung.erholung += werte.erholung;
        wirkung.teile[set] = (wirkung.teile[set] ?? 0) + 1;
      }
    }
  }
  return wirkung;
}
