// Trefferverarbeitung: Schadensfaktoren, Kombos, Waffen-Passive und Blutung.
import { EquipmentSlot, EntityDamageCause } from "@minecraft/server";
import { zustand, jetzt, verbrauche, melde, ladung, HALTUNGEN } from "./zustand.js";
import {
  waffeIn, istIntern, istHinter, heile, wahrerSchaden, effekt, klang, partikel, stoss,
  richtungXZ, gegnerImKegel, blocktMitSchild, animation, spaeter, leben, blickXZ,
} from "./werkzeuge.js";
import { verteidige } from "./verteidigung.js";
import { ganzkoerper } from "./haltung.js";

const KOMBO_FENSTER = 30; // Ticks, in denen der nächste Treffer die Kombo fortsetzt

// Blutung: Wesen-ID → { stapel, bis, quelle }
const blutungen = new Map();

// ---------------------------------------------------------------------------
// Angriffstempo
// ---------------------------------------------------------------------------
// Wie im Java-Kampfsystem lädt sich jeder Schlag nach dem letzten wieder auf.
// Wer schneller klickt, als die Waffe erlaubt, trifft nur schwach
// (Schaden = 20 % + 80 % × Aufladung²). Das ergänzt die Vanilla-Abklingzeit der
// Items und funktioniert auch dann, wenn diese im Spiel nicht greift.

/** Aufladung (0 … 1) der Waffe in der Hand zum Zeitpunkt t. */
export function aufladung(spieler, waffe, t = jetzt()) {
  const z = zustand(spieler);
  const cdTicks = Math.max(1, waffe.cd * 20);
  return Math.min(1, (t - z.letzterSchwung) / cdTicks);
}

export function tempoFaktor(ladung) {
  return 0.2 + 0.8 * ladung * ladung;
}

/** Waffenwechsel setzt die Aufladung zurück (verhindert Wechsel-Tricks). */
export function waffeGewechselt(spieler) {
  if (waffeIn(spieler)) zustand(spieler).letzterSchwung = jetzt();
}

// ---------------------------------------------------------------------------
// Schwung (Angriffsbeginn): Ausdauer und Körperanimation
// ---------------------------------------------------------------------------

export function schwungBeginn(spieler) {
  const waffe = waffeIn(spieler);
  if (!waffe) return;
  const z = zustand(spieler);
  const t = jetzt();
  z.aufladung = aufladung(spieler, waffe, t);
  z.letzterSchwung = t;
  const h = HALTUNGEN[z.haltung];

  // Art des Schlags: aus dem Block aufgeladen, aus dem Sprint oder normal.
  const lad = ladung(spieler);
  let art = "normal";
  if (lad >= 0.3) art = "kraft";
  else if (spieler.isSprinting && z.aufladung >= 0.8) art = "sturm";
  z.schlagArt = art;
  z.schlagFaktor = art === "kraft" ? 1 + 0.9 * lad : art === "sturm" ? 1.25 : 1;

  // Überhastete Schläge kosten nur einen Teil der Ausdauer, bringen aber auch wenig.
  const mehrkosten = art === "kraft" ? 1.5 : art === "sturm" ? 1.2 : 1;
  const kosten = Math.round(waffe.kosten * h.kosten * mehrkosten * (0.4 + 0.6 * z.aufladung));
  if (!verbrauche(spieler, kosten)) {
    melde(spieler, "§cErschöpft – schwache Schläge!", 30);
  }

  if (art === "kraft") {
    // Kraftschlag: aus der Lade-Pose mit einem Ausfallschritt durchziehen.
    ganzkoerper(spieler, `animation.mkampf.kraft.${waffe.artId}`, waffe.art.kraftDauer);
    z.blockStart = t; // Aufladung verbraucht, der Block bleibt bestehen
    // Schub und Zeitpunkt je Waffe: Rapier und Speer fallen weit aus, der Hammer kaum.
    const schub = waffe.art.kraftSchub * (0.5 + 0.5 * lad);
    spaeter(Math.round(waffe.art.kraftDauer * 20 * waffe.art.kraftZeit), () => stoss(spieler, blickXZ(spieler), schub, 0.05));
    melde(spieler, `§6§l${waffe.art.kraftName.toUpperCase()} §7(Kraftschlag ${Math.round(lad * 100)} %)`, 30);
    klang(spieler, "mob.warden.attack", 0.5, 0.9);
    z.schwerBis = t + Math.round(waffe.art.kraftDauer * 20 * 0.7);
    return;
  }
  if (art === "sturm") {
    // Sturmangriff: der Schwung des Sprints trägt den Schlag nach vorn.
    ganzkoerper(spieler, `animation.mkampf.sturm.${waffe.artId}`, waffe.art.sturmDauer);
    stoss(spieler, blickXZ(spieler), waffe.art.sturmSchub, 0.12);
    melde(spieler, `§e${waffe.art.sturmName}! §7(Sturmangriff)`, 25);
    klang(spieler, "mob.phantom.swoop", 0.5, 1.2);
    return;
  }

  // Die Animation folgt der Kombo: Technik 1 → 2 → 3 (→ 4) → 1 …
  // Ein überhasteter Schlag bricht die Folge ab und beginnt von vorn.
  if (z.aufladung < 0.8) z.angriffsSchritt = 0;
  z.angriffsSchritt = (z.angriffsSchritt % waffe.art.angriffe.length) + 1;
  const i = z.angriffsSchritt - 1;
  z.technik = waffe.art.angriffe[i];
  const dauer = waffe.art.angriffDauer[i];
  ganzkoerper(spieler, `animation.mkampf.angriff.${waffe.artId}.${z.angriffsSchritt}`, dauer);

  // Körperbewegung der Technik: Ausfallschritt, Nachsetzen oder Zurückziehen.
  const [schub, zeitpunkt] = waffe.art.schritte[i];
  if (z.aufladung >= 0.8 && schub !== 0) {
    spaeter(Math.round(dauer * 20 * zeitpunkt), () => stoss(spieler, blickXZ(spieler), schub, 0.02));
  }
  // Schwere Waffen bremsen während des Schlags.
  if (waffe.art.gewicht < 0.97) z.schwerBis = t + Math.round(dauer * 20 * 0.7);

  if (waffe.stil === "ueberkopf" || waffe.schaden >= 8) klang(spieler, "mob.warden.attack", 0.25, 1.6);
  else klang(spieler, "item.trident.throw", 0.3, 1.5 + Math.random() * 0.3);
}

// ---------------------------------------------------------------------------
// Treffer (auch geblockte): Schildbrechen und Morgenstern
// ---------------------------------------------------------------------------

export function trefferVersuch(angreifer, opfer) {
  const waffe = waffeIn(angreifer);
  if (!waffe || !blocktMitSchild(opfer)) return;
  if (waffe.artId === "streitaxt" || waffe.artId === "kriegshammer") {
    brecheSchild(opfer, waffe.artId === "kriegshammer" ? 80 : 60);
  } else if (waffe.artId === "morgenstern") {
    // Die Kugel schwingt über den Schildrand hinweg.
    spaeter(1, () => wahrerSchaden(opfer, waffe.schaden * 0.4, angreifer));
    klang(opfer, "random.anvil_land", 0.3, 1.5);
  }
}

export function brecheSchild(opfer, ticks) {
  if (opfer.typeId !== "minecraft:player") return;
  try {
    opfer.startItemCooldown("shield", ticks);
  } catch {
    // Kategorie unbekannt – ignorieren.
  }
  klang(opfer, "random.break", 1, 0.8);
  klang(opfer, "item.shield.block", 1, 0.5);
  melde(opfer, "§4Dein Schild wurde zerschlagen!", 40);
}

// ---------------------------------------------------------------------------
// Zentrale Schadensverarbeitung
// ---------------------------------------------------------------------------

export function beiSchaden(ereignis) {
  const opfer = ereignis.hurtEntity;
  if (!opfer || opfer.typeId === "mkampf:kampfbuch_offen" || istIntern(opfer)) return;
  const quelle = ereignis.damageSource;
  const schaden = ereignis.damage;
  if (!opfer?.isValid || schaden <= 0) return;
  const angreifer = quelle.damagingEntity;
  const nahkampf = quelle.cause === EntityDamageCause.entityAttack && angreifer?.isValid;

  // 1) Verteidigung des Opfers (nur Spieler).
  if (opfer.typeId === "minecraft:player") {
    const z = zustand(opfer);
    z.kombo = 0; // Getroffen werden bricht die eigene Kombo
    const abwehr = verteidige(opfer, nahkampf ? angreifer : undefined, schaden);
    if (abwehr.erstattung > 0) {
      heile(opfer, schaden * abwehr.erstattung);
      if (abwehr.rueckwurf > 0 && angreifer) wahrerSchaden(angreifer, abwehr.rueckwurf, opfer);
      return;
    }
  }
  if (!nahkampf || angreifer.typeId !== "minecraft:player") {
    schutzDerHaltung(opfer, schaden);
    return;
  }

  // 2) Angriff mit einer Mittelalter-Waffe?
  const waffe = waffeIn(angreifer);
  if (!waffe) {
    schutzDerHaltung(opfer, schaden);
    return;
  }
  const za = zustand(angreifer);
  const t = jetzt();
  let faktor = HALTUNGEN[za.haltung].schaden;
  const hinweise = [];

  // Erschöpft oder betäubt: deutlich schwächere Schläge.
  if (za.erschoepft) faktor *= 0.6;

  // Angriffstempo: Treffer aus einem frischen Schwung nutzen dessen Aufladung.
  // (Treffer ohne eigenen Schwung, z. B. Speer-Ansturm, gelten als voll geladen.)
  const ladung = t - za.letzterSchwung <= 2 ? za.aufladung : 1;
  faktor *= tempoFaktor(ladung);
  const voll = ladung >= 0.8;
  if (!voll) hinweise.push(`§7Zu hastig (${Math.round(ladung * 100)} %)`);
  // Kraftschlag und Sturmangriff verstärken den Treffer.
  if (t - za.letzterSchwung <= 2 && za.schlagFaktor > 1) {
    faktor *= za.schlagFaktor;
    const kraft = za.schlagArt === "kraft";
    hinweise.push(kraft ? `§6${waffe.art.kraftName}!` : `§e${waffe.art.sturmName}!`);
    if (kraft) stoss(opfer, richtungXZ(angreifer.location, opfer.location), 0.9, 0.25);
  }
  if (t < za.betaeubtBis) faktor *= 0.5;

  // Kombo auf dasselbe Ziel.
  // Nur voll aufgeladene Schläge bauen die Kombo auf.
  if (!voll) za.kombo = 0;
  else if (za.komboZiel === opfer.id && t - za.komboZeit <= KOMBO_FENSTER) za.kombo++;
  else za.kombo = 1;
  za.komboZiel = opfer.id;
  za.komboZeit = t;
  const finisher = za.kombo >= 3 && za.kombo % 3 === 0;
  if (finisher) {
    faktor *= waffe.artId === "langschwert" ? 1.5 : 1.35;
    hinweise.push("§d§lFINISHER!");
    klang(opfer, "random.anvil_land", 0.35, 1.6);
    partikel(opfer, "minecraft:critical_hit_emitter");
  }

  // Rückenstich.
  const buff = za.buff && t <= za.buff.bis ? za.buff : null;
  if (istHinter(angreifer, opfer) || buff?.art === "rueckenstich") {
    faktor *= waffe.artId === "doppeldolche" ? 1.75 : 1.2;
    hinweise.push("§5Rückenstich!");
  }

  // Waffenspezifische Verstärkungen.
  if (waffe.artId === "rapier" && (angreifer.isSprinting || angreifer.isFalling)) {
    faktor *= 1.5;
    hinweise.push("§eKritischer Stich!");
    partikel(opfer, "minecraft:critical_hit_emitter");
  }
  if (waffe.artId === "speer" && angreifer.isSprinting) faktor *= 1.3;
  if (waffe.artId === "doppeldolche" && waffeIn(angreifer, EquipmentSlot.Offhand)?.artId === "doppeldolche") {
    faktor *= 1.15;
    // Beidhändig: die zweite Klinge sticht kurz nach.
    spaeter(5, () => {
      if (opfer.isValid) {
        wahrerSchaden(opfer, 1.5, angreifer);
        klang(opfer, "item.trident.hit", 0.4, 1.8);
        ganzkoerper(angreifer, "animation.mkampf.angriff.doppeldolche.2", waffe.art.angriffDauer[1]);
      }
    });
  }
  if (buff?.art === "stoss") {
    faktor *= 1.4;
    hinweise.push("§6Halbschwert!");
  }
  if (buff) za.buff = null;

  // Schutz durch die Haltung des Opfers.
  if (opfer.typeId === "minecraft:player") faktor *= HALTUNGEN[zustand(opfer).haltung].schutz;

  // Faktor anwenden (Bonus als wahrer Schaden, Malus als Heilung).
  if (faktor > 1.001) wahrerSchaden(opfer, schaden * (faktor - 1), angreifer);
  else if (faktor < 0.999) heile(opfer, schaden * (1 - faktor));

  passiv(angreifer, opfer, waffe, schaden * faktor, buff);
  if (voll && za.technik) hinweise.unshift(`§e${za.technik}`);
  if (za.kombo >= 2) hinweise.unshift(`§dKombo x${za.kombo}`);
  if (hinweise.length) melde(angreifer, hinweise.join(" §7| "), 25);
}

function schutzDerHaltung(opfer, schaden) {
  if (opfer.typeId !== "minecraft:player") return;
  const schutz = HALTUNGEN[zustand(opfer).haltung].schutz;
  if (schutz < 1) heile(opfer, schaden * (1 - schutz));
}

// ---------------------------------------------------------------------------
// Passive Waffeneffekte
// ---------------------------------------------------------------------------

function passiv(angreifer, opfer, waffe, schaden, buff) {
  const richtung = richtungXZ(angreifer.location, opfer.location);
  switch (waffe.artId) {
    case "doppeldolche":
      blute(opfer, angreifer, 2);
      break;
    case "saebel":
      blute(opfer, angreifer, 1);
      effekt(angreifer, "speed", 40, 0, false);
      break;
    case "rapier":
      // Dünne Klinge findet die Lücken der Rüstung.
      wahrerSchaden(opfer, 1, angreifer);
      break;
    case "zweihaender":
      // Schwungschaden an weiteren Gegnern im Bogen vor dem Angreifer.
      for (const e of gegnerImKegel(angreifer, 3.2, 0.3)) {
        if (e.id !== opfer.id) {
          wahrerSchaden(e, schaden * 0.4, angreifer);
          partikel(e, "minecraft:critical_hit_emitter");
        }
      }
      klang(angreifer, "mob.warden.attack", 0.3, 1.3);
      break;
    case "streitaxt":
      stoss(opfer, richtung, 0.5, 0.2);
      break;
    case "kriegshammer":
      effekt(opfer, "slowness", 30, 2, false);
      stoss(opfer, richtung, 1.1, 0.35);
      klang(opfer, "random.anvil_land", 0.4, 0.6);
      if (opfer.typeId === "minecraft:player") animation(opfer, "animation.mkampf.sonder.betaeubt", "mkampf.angriff");
      break;
    case "streitkolben":
      wahrerSchaden(opfer, 1.5, angreifer);
      effekt(opfer, "mining_fatigue", 40, 1, false);
      break;
    case "morgenstern":
      stoss(opfer, richtung, 0.4, 0.15);
      break;
    case "hellebarde":
      stoss(opfer, richtung, 0.8, 0.2);
      break;
    case "kriegssense":
      heile(angreifer, schaden * 0.2);
      partikel(opfer, "minecraft:soul_particle");
      break;
  }
  if (buff?.art === "schaedel") {
    effekt(opfer, "slowness", 40, 3, false);
    effekt(opfer, "nausea", 80, 0, false);
    effekt(opfer, "blindness", 25, 0, false);
    wahrerSchaden(opfer, 2, angreifer);
    klang(opfer, "random.anvil_land", 0.6, 0.5);
    melde(angreifer, "§6§lSCHÄDELSPALTER!", 30);
    if (opfer.typeId === "minecraft:player") {
      zustand(opfer).betaeubtBis = jetzt() + 40;
      melde(opfer, "§cDu bist betäubt!", 40);
      animation(opfer, "animation.mkampf.sonder.betaeubt", "mkampf.angriff");
    }
  }
}

// ---------------------------------------------------------------------------
// Blutung
// ---------------------------------------------------------------------------

export function blute(opfer, quelle, stapel) {
  const b = blutungen.get(opfer.id) ?? { stapel: 0, bis: 0, opfer, quelle };
  b.stapel = Math.min(5, b.stapel + stapel);
  b.bis = jetzt() + 60;
  b.quelle = quelle;
  b.opfer = opfer;
  blutungen.set(opfer.id, b);
}

/** Wird jede Sekunde aufgerufen: Blutungsschaden. */
export function blutungsSchleife() {
  const t = jetzt();
  for (const [id, b] of blutungen) {
    if (!b.opfer.isValid || t > b.bis || leben(b.opfer) <= 0) {
      blutungen.delete(id);
      continue;
    }
    wahrerSchaden(b.opfer, 0.5 * b.stapel, b.quelle?.isValid ? b.quelle : undefined);
    partikel(b.opfer, "minecraft:redstone_ore_dust_particle", 1.0);
    partikel(b.opfer, "minecraft:redstone_ore_dust_particle", 0.6);
    klang(b.opfer, "game.player.hurt", 0.25, 1.3);
  }
}
