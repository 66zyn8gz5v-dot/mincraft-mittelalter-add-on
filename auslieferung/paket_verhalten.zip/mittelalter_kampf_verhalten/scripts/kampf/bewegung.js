// Bewegung im Kampf: schwere Waffen machen langsamer, leichte schneller. Blocken und
// schwere Schläge bremsen zusätzlich – so fühlt sich jede Waffe anders an.
import { world } from "@minecraft/server";
import { zustand, jetzt, ladung } from "./zustand.js";
import { waffeIn, ruestungsWirkung } from "./werkzeuge.js";

/** Läuft alle 4 Ticks und passt die Laufgeschwindigkeit an. */
export function bewegungsSchleife() {
  const t = jetzt();
  for (const spieler of world.getAllPlayers()) {
    let tempo;
    try {
      tempo = spieler.getComponent("minecraft:movement");
    } catch {
      continue;
    }
    if (!tempo) continue;
    const z = zustand(spieler);
    const waffe = waffeIn(spieler);
    let faktor = waffe ? waffe.art.gewicht : 1;
    if (waffe && z.block) faktor *= ladung(spieler) > 0 ? 0.8 : 0.9;
    if (t < z.schwerBis) faktor *= 0.55;
    // Rüstung: Plattenrüstung bremst (bis −8 % bei vollem Set).
    faktor *= 1 + ruestungsWirkung(spieler).tempo;
    const ziel = tempo.defaultValue * faktor;
    if (Math.abs(tempo.currentValue - ziel) > 0.0001) {
      try {
        tempo.setCurrentValue(ziel);
      } catch {
        // Wert außerhalb des erlaubten Bereichs – ignorieren.
      }
    }
  }
}
