// Verteidigung: Parade (Schleichen antippen) und Ausweichen (doppelt antippen).
import { zustand, jetzt, verbrauche, melde, HALTUNGEN } from "./zustand.js";
import { waffeIn, klang, partikel, stoss, animation, blickXZ, effekt } from "./werkzeuge.js";

const DOPPELTIPP = 7; // Ticks zwischen zwei Schleich-Tipps für Ausweichen
const PARADE_KOSTEN = 5;
const AUSWEICH_KOSTEN = 25;
const KEINE = { erstattung: 0, rueckwurf: 0 };

/** Wird beim Drücken der Schleichtaste aufgerufen. */
export function schleichenGedrueckt(spieler) {
  const z = zustand(spieler);
  const t = jetzt();
  if (!waffeIn(spieler)) {
    z.letztesSchleichen = t;
    return;
  }

  // Doppeltipp + Bewegung = Ausweichen.
  if (t - z.letztesSchleichen <= DOPPELTIPP && t >= z.ausweichSperre) {
    const bewegung = spieler.inputInfo.getMovementVector();
    if (Math.abs(bewegung.x) + Math.abs(bewegung.y) > 0.2) {
      z.letztesSchleichen = 0;
      ausweichen(spieler, bewegung);
      return;
    }
  }
  z.letztesSchleichen = t;

  // Einfacher Tipp = Parade.
  if (t < z.paradeSperre) return;
  if (!verbrauche(spieler, PARADE_KOSTEN)) {
    melde(spieler, "§cZu erschöpft zum Parieren!");
    return;
  }
  z.paradeBis = t + HALTUNGEN[z.haltung].parade;
  z.paradeSperre = t + 20;
  animation(spieler, "animation.mkampf.sonder.parade", "mkampf.angriff");
}

function ausweichen(spieler, bewegung) {
  const z = zustand(spieler);
  if (!verbrauche(spieler, AUSWEICH_KOSTEN)) {
    melde(spieler, "§cZu erschöpft zum Ausweichen!");
    return;
  }
  // Bewegungsvektor (x = seitlich, y = vorwärts) in Weltrichtung umrechnen.
  const vorn = blickXZ(spieler);
  const rechts = { x: -vorn.z, z: vorn.x };
  let rx = vorn.x * bewegung.y - rechts.x * bewegung.x;
  let rz = vorn.z * bewegung.y - rechts.z * bewegung.x;
  const l = Math.sqrt(rx * rx + rz * rz) || 1;
  rx /= l;
  rz /= l;
  stoss(spieler, { x: rx, z: rz }, 1.6, 0.18);
  const t = jetzt();
  z.ausweichenBis = t + 8;
  z.ausweichSperre = t + 24;
  z.paradeBis = 0;
  klang(spieler, "mob.phantom.swoop", 0.6, 1.6);
  partikel(spieler, "minecraft:cauldron_explosion_emitter", 0.2);
  animation(spieler, "animation.mkampf.sonder.ausweichen", "mkampf.angriff");
}

/**
 * Prüft beim Treffer eines Spielers, ob Parade/Ausweichen/Riposte greift.
 * Rückgabe: { erstattung: Anteil des Schadens, der zurückerstattet wird,
 *             rueckwurf: Schaden, der auf den Angreifer zurückfällt }.
 */
export function verteidige(opfer, angreifer, schaden) {
  const z = zustand(opfer);
  const t = jetzt();

  if (t <= z.ausweichenBis) {
    melde(opfer, "§bAusgewichen!", 20);
    return { erstattung: 1.0, rueckwurf: 0 };
  }

  if (!angreifer) return KEINE;

  if (t <= z.riposteBis) {
    z.riposteBis = 0;
    melde(opfer, "§6§lRIPOSTE!", 30);
    klang(opfer, "item.trident.hit", 1, 1.4);
    klang(opfer, "random.anvil_land", 0.4, 1.8);
    partikel(angreifer, "minecraft:critical_hit_emitter");
    return { erstattung: 1.0, rueckwurf: schaden * 1.2 };
  }

  if (t <= z.paradeBis) {
    z.paradeBis = 0;
    z.paradeSperre = t + 6; // gelungene Parade darf schnell wiederholt werden
    z.ausdauer = Math.min(100, z.ausdauer + 15);
    melde(opfer, "§a§lPARIERT!", 25);
    klang(opfer, "item.shield.block", 1, 1.2);
    klang(opfer, "random.anvil_land", 0.35, 2.0);
    partikel(angreifer, "minecraft:critical_hit_emitter");
    // Der Angreifer gerät aus dem Gleichgewicht.
    effekt(angreifer, "slowness", 25, 1, false);
    effekt(angreifer, "weakness", 25, 0, false);
    stoss(angreifer, blickXZ(opfer), 0.6, 0.15);
    if (angreifer.typeId === "minecraft:player") {
      zustand(angreifer).betaeubtBis = t + 20;
      melde(angreifer, "§cPariert – aus dem Gleichgewicht!", 25);
      animation(angreifer, "animation.mkampf.sonder.betaeubt", "mkampf.angriff");
    }
    return { erstattung: z.haltung === "tief" ? 1.0 : 0.8, rueckwurf: 0 };
  }
  return KEINE;
}
