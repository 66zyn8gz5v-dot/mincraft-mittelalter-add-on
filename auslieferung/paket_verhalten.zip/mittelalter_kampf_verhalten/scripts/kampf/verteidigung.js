// Verteidigung: Parade (Schleichen antippen), Waffenblock (Schleichen halten, lädt zugleich
// einen Kraftschlag auf) und Ausweichrolle (doppelt antippen + Laufrichtung).
import { zustand, jetzt, verbrauche, melde, HALTUNGEN } from "./zustand.js";
import {
  waffeIn, klang, partikel, stoss, animation, blickXZ, richtungXZ, effekt, eigenklang, partikelZwischen,
} from "./werkzeuge.js";
import { aktualisierePose } from "./haltung.js";

const DOPPELTIPP = 7; // Ticks zwischen zwei Schleich-Tipps für Ausweichen
const PARADE_KOSTEN = 5;
const AUSWEICH_KOSTEN = 25;
// Anteil des abgewehrten Schadens beim Waffenblock je Griffart.
const BLOCK_ANTEIL = { einhand: 0.5, zweihand: 0.6, stange: 0.55 };
const KEINE = { erstattung: 0, rueckwurf: 0 };

/** Wird beim Drücken der Schleichtaste aufgerufen. */
export function schleichenGedrueckt(spieler) {
  const z = zustand(spieler);
  const t = jetzt();
  if (!waffeIn(spieler)) {
    z.letztesSchleichen = t;
    return;
  }
  // Solange Schleichen gehalten wird, blockt der Kämpfer und lädt einen Kraftschlag auf.
  z.block = true;
  z.blockStart = t;
  aktualisierePose(spieler);

  // Doppeltipp + Bewegung = Ausweichen.
  if (t - z.letztesSchleichen <= DOPPELTIPP && t >= z.ausweichSperre) {
    const bewegung = spieler.inputInfo.getMovementVector();
    if (Math.abs(bewegung.x) + Math.abs(bewegung.y) > 0.2) {
      z.letztesSchleichen = 0;
      ausweichen(spieler, bewegung);
      return;
    }
  }
  z.letztesSchleichen = t;

  // Einfacher Tipp = Parade.
  if (t < z.paradeSperre) return;
  if (!verbrauche(spieler, PARADE_KOSTEN)) {
    melde(spieler, "§cZu erschöpft zum Parieren!");
    return;
  }
  z.paradeBis = t + HALTUNGEN[z.haltung].parade;
  z.paradeSperre = t + 20;
  animation(spieler, "animation.mkampf.sonder.parade", "mkampf.angriff");
}

/** Wird beim Loslassen der Schleichtaste aufgerufen: Block und Aufladung enden. */
export function schleichenLosgelassen(spieler) {
  const z = zustand(spieler);
  if (!z.block) return;
  z.block = false;
  z.blockStart = 0;
  aktualisierePose(spieler);
}

function ausweichen(spieler, bewegung) {
  const z = zustand(spieler);
  if (!verbrauche(spieler, AUSWEICH_KOSTEN)) {
    melde(spieler, "§cZu erschöpft zum Ausweichen!");
    return;
  }
  // Bewegungsvektor (x = seitlich, y = vorwärts) in Weltrichtung umrechnen.
  const vorn = blickXZ(spieler);
  const rechts = { x: -vorn.z, z: vorn.x };
  let rx = vorn.x * bewegung.y - rechts.x * bewegung.x;
  let rz = vorn.z * bewegung.y - rechts.z * bewegung.x;
  const l = Math.sqrt(rx * rx + rz * rz) || 1;
  rx /= l;
  rz /= l;
  stoss(spieler, { x: rx, z: rz }, 1.5, 0.12);
  const t = jetzt();
  z.ausweichenBis = t + 10;
  z.block = false;
  z.ausweichSperre = t + 24;
  z.paradeBis = 0;
  klang(spieler, "mob.phantom.swoop", 0.6, 1.6);
  partikel(spieler, "minecraft:cauldron_explosion_emitter", 0.2);
  // Rolle in Laufrichtung (x > 0 = nach links, y > 0 = nach vorn).
  const richtung = Math.abs(bewegung.y) >= Math.abs(bewegung.x)
    ? (bewegung.y > 0 ? "vorn" : "hinten")
    : (bewegung.x > 0 ? "links" : "rechts");
  animation(spieler, `animation.mkampf.rolle.${richtung}`, "mkampf.angriff", 0.05);
}

/** Steht der Angreifer vor dem Verteidiger? (Blocken geht nur nach vorn) */
function vorDemOpfer(opfer, angreifer) {
  const blick = blickXZ(opfer);
  const r = richtungXZ(opfer.location, angreifer.location);
  return blick.x * r.x + blick.z * r.z > 0.25;
}

/** Waffenblock: wehrt einen Teil des Schadens ab oder bricht bei zu wenig Ausdauer. */
function blocke(opfer, angreifer, schaden) {
  const z = zustand(opfer);
  const t = jetzt();
  const waffe = waffeIn(opfer);
  if (!waffe || !z.block || !opfer.isSneaking || !vorDemOpfer(opfer, angreifer)) return null;
  const za = angreifer.typeId === "minecraft:player" ? zustand(angreifer) : null;
  const kraftschlag = za && t - za.letzterSchwung <= 2 && za.schlagArt === "kraft";
  const brecher = ["streitaxt", "kriegshammer"].includes(waffeIn(angreifer)?.artId);
  const kosten = Math.round(schaden * 2.5 * (brecher ? 2 : 1));
  if (kraftschlag || !verbrauche(opfer, kosten)) {
    // Deckung gebrochen: voller Schaden, kurz aus dem Gleichgewicht.
    z.block = false;
    z.betaeubtBis = t + 25;
    effekt(opfer, "slowness", 25, 2, false);
    melde(opfer, "§4§lDECKUNG GEBROCHEN!", 30);
    if (za) melde(angreifer, "§6Deckung durchbrochen!", 25);
    klang(opfer, "random.break", 1, 0.7);
    animation(opfer, "animation.mkampf.sonder.betaeubt", "mkampf.angriff");
    aktualisierePose(opfer);
    return KEINE;
  }
  let anteil = BLOCK_ANTEIL[waffe.griff] ?? 0.5;
  if (z.haltung === "tief") anteil += 0.15;
  melde(opfer, `§bGeblockt §7(−${Math.round(anteil * 100)} %)`, 20);
  animation(opfer, "animation.mkampf.sonder.blocktreffer", "mkampf.angriff", 0.05);
  klang(opfer, "item.shield.block", 0.5, 1.5);
  eigenklang(opfer, "mkampf.klinge", 1, 1.0);
  partikelZwischen(angreifer, opfer, "mkampf:funken");
  stoss(opfer, richtungXZ(angreifer.location, opfer.location), 0.25, 0.02);
  return { erstattung: anteil, rueckwurf: 0 };
}

/**
 * Prüft beim Treffer eines Spielers, ob Parade/Ausweichen/Riposte greift.
 * Rückgabe: { erstattung: Anteil des Schadens, der zurückerstattet wird,
 *             rueckwurf: Schaden, der auf den Angreifer zurückfällt }.
 */
export function verteidige(opfer, angreifer, schaden) {
  const z = zustand(opfer);
  const t = jetzt();

  if (t <= z.ausweichenBis) {
    melde(opfer, "§bAusgewichen!", 20);
    return { erstattung: 1.0, rueckwurf: 0 };
  }

  if (!angreifer) return KEINE;

  if (t <= z.riposteBis) {
    z.riposteBis = 0;
    melde(opfer, "§6§lRIPOSTE!", 30);
    klang(opfer, "item.trident.hit", 0.6, 1.4);
    eigenklang(opfer, "mkampf.parade", 1, 1.2);
    partikelZwischen(angreifer, opfer, "mkampf:funken");
    return { erstattung: 1.0, rueckwurf: schaden * 1.2 };
  }

  if (t <= z.paradeBis) {
    z.paradeBis = 0;
    z.paradeSperre = t + 6; // gelungene Parade darf schnell wiederholt werden
    z.ausdauer = Math.min(100, z.ausdauer + 15);
    melde(opfer, "§a§lPARIERT!", 25);
    klang(opfer, "item.shield.block", 0.5, 1.2);
    eigenklang(opfer, "mkampf.parade", 1, 1.0);
    partikelZwischen(angreifer, opfer, "mkampf:funken");
    // Der Angreifer gerät aus dem Gleichgewicht.
    effekt(angreifer, "slowness", 25, 1, false);
    effekt(angreifer, "weakness", 25, 0, false);
    stoss(angreifer, blickXZ(opfer), 0.6, 0.15);
    if (angreifer.typeId === "minecraft:player") {
      zustand(angreifer).betaeubtBis = t + 20;
      melde(angreifer, "§cPariert – aus dem Gleichgewicht!", 25);
      animation(angreifer, "animation.mkampf.sonder.betaeubt", "mkampf.angriff");
    }
    return { erstattung: z.haltung === "tief" ? 1.0 : 0.8, rueckwurf: 0 };
  }
  return blocke(opfer, angreifer, schaden) ?? KEINE;
}

/**
 * Trefferreaktion des getroffenen Spielers: Der Körper weicht dem Schlag aus dessen Richtung
 * aus (vorn, hinten, links, rechts); schwere Treffer (Kraftschlag, Hammer, Axt) lassen ihn
 * taumeln. Läuft additiv über Haltung bzw. Angriff und unterbricht keine Rolle.
 */
export function trefferReaktion(opfer, angreifer, schaden) {
  const z = zustand(opfer);
  const t = jetzt();
  if (t <= z.ausweichenBis + 2 || t < (z.reaktionBis ?? 0)) return;
  z.reaktionBis = t + 5;
  const za = angreifer.typeId === "minecraft:player" ? zustand(angreifer) : null;
  const kraft = za && t - za.letzterSchwung <= 2 && za.schlagArt === "kraft";
  const wucht = ["kriegshammer", "streitaxt"].includes(waffeIn(angreifer)?.artId) && schaden >= 7;
  let art = "schwer";
  if (!kraft && !wucht) {
    // Richtung des Angreifers aus Sicht des Opfers (Kreuzprodukt > 0 = von rechts).
    const blick = blickXZ(opfer);
    const r = richtungXZ(opfer.location, angreifer.location);
    const vorn = blick.x * r.x + blick.z * r.z;
    const seite = blick.x * r.z - blick.z * r.x;
    art = vorn > 0.5 ? "vorn" : vorn < -0.5 ? "hinten" : seite > 0 ? "rechts" : "links";
  }
  animation(opfer, `animation.mkampf.sonder.getroffen.${art}`, "mkampf.angriff", 0.05);
}
