// Zweihandwaffen sperren die Nebenhand: Der Gegenstand dort wird ins Inventar
// ausgelagert und ein rotes X („Gesperrt“) belegt den Slot, bis die Waffe
// wieder weggesteckt wird. Danach kommt der alte Gegenstand zurück.
import { world, system, ItemStack, ItemLockMode, EquipmentSlot } from "@minecraft/server";
import { waffeIn, klang } from "./werkzeuge.js";
import { melde } from "./zustand.js";

export const SPERRE = "mkampf:gesperrt";
const SLOT_EIGENSCHAFT = "mkampf:nebenhand_slot";
const TYP_EIGENSCHAFT = "mkampf:nebenhand_typ";

function sperrItem() {
  const item = new ItemStack(SPERRE);
  item.lockMode = ItemLockMode.slot; // lässt sich weder bewegen noch fallen lassen
  item.keepOnDeath = true; // wird nie als Beute fallen gelassen
  return item;
}

/** Prüft einen Spieler und setzt bzw. löst die Sperre. */
export function pruefeNebenhand(spieler) {
  const ausruestung = spieler.getComponent("minecraft:equippable");
  const inventar = spieler.getComponent("minecraft:inventory")?.container;
  if (!ausruestung || !inventar) return;
  const waffe = waffeIn(spieler);
  const neben = ausruestung.getEquipment(EquipmentSlot.Offhand);

  if (waffe?.art.zweihaendig) {
    if (neben?.typeId === SPERRE) return;
    if (neben) auslagern(spieler, inventar, neben);
    ausruestung.setEquipment(EquipmentSlot.Offhand, sperrItem());
    melde(spieler, `§c✖ ${waffe.art.name}: beide Hände am Griff – Nebenhand gesperrt`, 40);
    klang(spieler, "armor.equip_generic", 0.6, 0.8);
    return;
  }

  if (neben?.typeId === SPERRE) {
    ausruestung.setEquipment(EquipmentSlot.Offhand, undefined);
    zurueckholen(spieler, inventar, ausruestung);
  }
}

function auslagern(spieler, inventar, item) {
  const slot = inventar.firstEmptySlot();
  if (slot === undefined) {
    // Inventar voll: Gegenstand fällt vor die Füße, damit nichts verloren geht.
    spieler.dimension.spawnItem(item, spieler.location);
    melde(spieler, "§6Inventar voll – Nebenhand-Gegenstand fallen gelassen", 50);
    spieler.setDynamicProperty(SLOT_EIGENSCHAFT, undefined);
    return;
  }
  inventar.setItem(slot, item);
  spieler.setDynamicProperty(SLOT_EIGENSCHAFT, slot);
  spieler.setDynamicProperty(TYP_EIGENSCHAFT, item.typeId);
}

function zurueckholen(spieler, inventar, ausruestung) {
  const slot = spieler.getDynamicProperty(SLOT_EIGENSCHAFT);
  const typ = spieler.getDynamicProperty(TYP_EIGENSCHAFT);
  spieler.setDynamicProperty(SLOT_EIGENSCHAFT, undefined);
  spieler.setDynamicProperty(TYP_EIGENSCHAFT, undefined);
  if (typeof slot !== "number") return;
  const item = inventar.getItem(slot);
  // Nur zurücklegen, wenn dort noch derselbe Gegenstand liegt.
  if (!item || item.typeId !== typ) return;
  inventar.setItem(slot, undefined);
  ausruestung.setEquipment(EquipmentSlot.Offhand, item);
}

/** Entfernt verirrte Sperr-Items aus dem Inventar (z. B. aus dem Kreativmenü). */
export function aufraeumen(spieler) {
  const inventar = spieler.getComponent("minecraft:inventory")?.container;
  if (!inventar) return;
  for (let i = 0; i < inventar.size; i++) {
    if (inventar.getItem(i)?.typeId === SPERRE) inventar.setItem(i, undefined);
  }
}

let zaehler = 0;
export function nebenhandSchleife() {
  zaehler++;
  for (const spieler of world.getAllPlayers()) {
    pruefeNebenhand(spieler);
    if (zaehler % 8 === 0) aufraeumen(spieler);
  }
}

/** Nach einem Hotbar-Wechsel sofort (im nächsten Tick) prüfen. */
export function nachWechsel(spieler) {
  system.run(() => {
    if (spieler.isValid) pruefeNebenhand(spieler);
  });
}
