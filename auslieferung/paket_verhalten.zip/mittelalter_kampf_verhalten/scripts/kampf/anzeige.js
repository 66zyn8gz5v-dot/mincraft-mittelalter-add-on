// Ausdauer-Regeneration und Kampfanzeige in der Aktionsleiste.
import { world } from "@minecraft/server";
import { zustand, jetzt, ladung, MAX_AUSDAUER, HALTUNGEN } from "./zustand.js";
import { waffeIn } from "./werkzeuge.js";
import { aufladung } from "./schaden.js";
import { ZEICHEN } from "../daten/zeichen.js";
import { hatBuckler } from "./verteidigung.js";

// Die Leisten bestehen aus eigenen Schriftzeichen (font/glyph_E1.png, erzeugt von tools/hud.py):
// ein Symbol und zehn farbige Stücke. §r vor den Zeichen verhindert, dass Farbcodes sie einfärben.
const STUECKE = 10;
const S = ZEICHEN.stueck;

/** Leiste aus Stücken: anteil 0 … 1, farbe = Name eines Leistenstücks. */
function leiste(anteil, farbe, stuecke = STUECKE) {
  const voll = Math.max(0, Math.min(stuecke, Math.round(anteil * stuecke)));
  return "§r" + S[farbe].repeat(voll) + S.leer.repeat(stuecke - voll);
}

function ausdauerFarbe(wert) {
  return wert < 25 ? "rot" : wert < 55 ? "gelb" : "gruen";
}

/** Läuft alle 2 Ticks. */
export function anzeigeSchleife() {
  const t = jetzt();
  for (const spieler of world.getAllPlayers()) {
    const z = zustand(spieler);

    // Regeneration nach kurzer Pause, im Sprint langsamer.
    if (t - z.letzteAnstrengung > 16 && z.ausdauer < MAX_AUSDAUER) {
      const rate = spieler.isSprinting ? 0.6 : z.haltung === "tief" ? 3.4 : 2.8;
      z.ausdauer = Math.min(MAX_AUSDAUER, z.ausdauer + rate);
    }
    if (z.erschoepft && z.ausdauer >= 30) z.erschoepft = false;

    const waffe = waffeIn(spieler);
    if (!waffe && z.ausdauer >= MAX_AUSDAUER && t > z.meldungBis) continue;

    const teile = [];
    if (waffe) {
      // Tempo-Anzeige wie die Angriffsleiste im Java-Kampfsystem.
      const ladung = aufladung(spieler, waffe, t);
      teile.push(`§r${ZEICHEN.schwert} ${leiste(ladung, ladung >= 1 ? "gold" : "weiss")}`);
    }
    teile.push(`${z.erschoepft ? "§c§lERSCHÖPFT §r" : "§r"}${ZEICHEN.ausdauer} ` +
      leiste(z.ausdauer / MAX_AUSDAUER, ausdauerFarbe(z.ausdauer)));
    if (waffe) {
      const h = HALTUNGEN[z.haltung];
      if (z.block && spieler.isSneaking) {
        const lad = ladung(spieler);
        teile.push(lad > 0
          ? `§r${ZEICHEN.kraft} ${leiste(lad, "orange")}${lad >= 1 ? ` §6§l${waffe.art.kraftName}` : ""}`
          : `§r${ZEICHEN.schild} §b${waffe.art.blockName}`);
      } else {
        teile.push(`§r${ZEICHEN.haltung} ${h.farbe}${h.name}${hatBuckler(spieler) ? ` §r${ZEICHEN.schild}` : ""}`);
      }
      // Fähigkeit: Rest der Abklingzeit als kleine lila Leiste (läuft zusätzlich auf dem Item ab).
      if (waffe.faehigkeit) {
        const rest = Math.max(0, z.faehigkeitBereit - t);
        teile.push(rest > 0
          ? `§r${ZEICHEN.stern} ${leiste(1 - rest / waffe.fcd, "lila", 5)} §7${Math.ceil(rest / 20)}s`
          : `§r${ZEICHEN.stern} §d${waffe.art.faehigkeitName}`);
      }
    }
    let text = teile.join("   ");
    if (t <= z.meldungBis && z.meldung) text = `${z.meldung}\n${text}`;
    try {
      spieler.onScreenDisplay.setActionBar(text);
    } catch {
      // Spieler lädt gerade.
    }
  }
}
