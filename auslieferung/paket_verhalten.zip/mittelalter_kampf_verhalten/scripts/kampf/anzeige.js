// Ausdauer-Regeneration und Kampfanzeige in der Aktionsleiste.
import { world } from "@minecraft/server";
import { zustand, jetzt, ladung, MAX_AUSDAUER, HALTUNGEN } from "./zustand.js";
import { waffeIn } from "./werkzeuge.js";
import { aufladung } from "./schaden.js";

const SEGMENTE = 20;

function balken(wert) {
  const voll = Math.round((wert / MAX_AUSDAUER) * SEGMENTE);
  const farbe = wert < 25 ? "§c" : wert < 55 ? "§6" : "§a";
  return farbe + "|".repeat(voll) + "§8" + "|".repeat(SEGMENTE - voll);
}

/** Läuft alle 2 Ticks. */
export function anzeigeSchleife() {
  const t = jetzt();
  for (const spieler of world.getAllPlayers()) {
    const z = zustand(spieler);

    // Regeneration nach kurzer Pause, im Sprint langsamer.
    if (t - z.letzteAnstrengung > 16 && z.ausdauer < MAX_AUSDAUER) {
      const rate = spieler.isSprinting ? 0.6 : z.haltung === "tief" ? 3.4 : 2.8;
      z.ausdauer = Math.min(MAX_AUSDAUER, z.ausdauer + rate);
    }
    if (z.erschoepft && z.ausdauer >= 30) z.erschoepft = false;

    const waffe = waffeIn(spieler);
    if (!waffe && z.ausdauer >= MAX_AUSDAUER && t > z.meldungBis) continue;

    const teile = [];
    if (waffe) {
      // Tempo-Anzeige wie die Angriffsleiste im Java-Kampfsystem.
      const ladung = aufladung(spieler, waffe, t);
      const tempo = ladung >= 1 ? "§f⚔" : `§7⚔ ${"§f▮".repeat(Math.round(ladung * 5))}${"§8▮".repeat(5 - Math.round(ladung * 5))}`;
      teile.push(`${tempo} §f${waffe.art.name}`);
    }
    teile.push(`${z.erschoepft ? "§c§lERSCHÖPFT " : ""}${balken(z.ausdauer)}`);
    if (waffe) {
      const h = HALTUNGEN[z.haltung];
      if (z.block && spieler.isSneaking) {
        const lad = ladung(spieler);
        const stufen = Math.round(lad * 5);
        teile.push(lad > 0
          ? `§6⚡ ${"§6▮".repeat(stufen)}${"§8▮".repeat(5 - stufen)}${lad >= 1 ? " §6§lVOLL" : ""}`
          : "§b🛡 Block");
      } else {
        teile.push(`${h.farbe}${h.name}`);
      }
      const rest = Math.max(0, z.faehigkeitBereit - t);
      teile.push(rest > 0 ? `§8✦ ${Math.ceil(rest / 20)}s` : "§6✦ bereit");
    }
    let text = teile.join(" §7• ");
    if (t <= z.meldungBis && z.meldung) text = `${z.meldung}\n${text}`;
    try {
      spieler.onScreenDisplay.setActionBar(text);
    } catch {
      // Spieler lädt gerade.
    }
  }
}
