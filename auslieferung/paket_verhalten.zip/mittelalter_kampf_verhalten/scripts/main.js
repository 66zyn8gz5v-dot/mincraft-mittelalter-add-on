// Einstiegspunkt des Add-ons „Mittelalter-Kampf“: verbindet alle Kampfmodule mit den Spielereignissen.
import {
  world, system, ItemStack, InputButton, ButtonState, EntitySwingSource,
} from "@minecraft/server";
import { vergessen } from "./kampf/zustand.js";
import { posenSchleife } from "./kampf/haltung.js";
import { schleichenGedrueckt } from "./kampf/verteidigung.js";
import {
  schwungBeginn, trefferVersuch, beiSchaden, blutungsSchleife, waffeGewechselt,
} from "./kampf/schaden.js";
import { nebenhandSchleife, nachWechsel, SPERRE } from "./kampf/nebenhand.js";
import { gegenstandBenutzt } from "./kampf/faehigkeiten.js";
import { anzeigeSchleife } from "./kampf/anzeige.js";
import { beiTod, beiVerlassen } from "./kampf/duell.js";
import { oeffneKampfbuch } from "./kampf/kampfbuch.js";

/** Führt eine Funktion aus und meldet Fehler in der Konsole, ohne das Skript zu stoppen. */
function sicher(name, funktion) {
  return (...argumente) => {
    try {
      funktion(...argumente);
    } catch (fehler) {
      console.warn(`[Mittelalter-Kampf] Fehler in ${name}: ${fehler}`);
    }
  };
}

// --- Ereignisse ------------------------------------------------------------

world.afterEvents.playerSwingStart.subscribe(sicher("Schwung", (e) => {
  if (e.swingSource === EntitySwingSource.Attack) schwungBeginn(e.player);
}));

world.afterEvents.entityHitEntity.subscribe(sicher("Treffer", (e) => {
  if (e.damagingEntity?.typeId === "minecraft:player") trefferVersuch(e.damagingEntity, e.hitEntity);
}));

world.afterEvents.entityHurt.subscribe(sicher("Schaden", beiSchaden));

world.afterEvents.playerButtonInput.subscribe(
  sicher("Schleichen", (e) => schleichenGedrueckt(e.player)),
  { buttons: [InputButton.Sneak], state: ButtonState.Pressed },
);

world.afterEvents.itemUse.subscribe(sicher("Benutzen", (e) => {
  if (e.itemStack?.typeId === SPERRE) return;
  if (e.itemStack?.typeId === "mkampf:kampfbuch") {
    system.run(() => oeffneKampfbuch(e.source).catch(() => {}));
    return;
  }
  gegenstandBenutzt(e.source, e.itemStack);
}));

// Waffenwechsel: Aufladung zurücksetzen und Nebenhand-Sperre sofort anpassen.
world.afterEvents.playerHotbarSelectedSlotChange.subscribe(sicher("Wechsel", (e) => {
  waffeGewechselt(e.player);
  nachWechsel(e.player);
}));

world.afterEvents.entityDie.subscribe(sicher("Tod", beiTod));

world.afterEvents.playerLeave.subscribe(sicher("Verlassen", (e) => {
  beiVerlassen(e.playerId);
  vergessen(e.playerId);
}));

// Neue Spieler bekommen einmalig das Kampfbuch.
world.afterEvents.playerSpawn.subscribe(sicher("Beitritt", (e) => {
  if (!e.initialSpawn) return;
  const spieler = e.player;
  if (spieler.getDynamicProperty("mkampf:buch_erhalten")) return;
  spieler.setDynamicProperty("mkampf:buch_erhalten", true);
  spieler.getComponent("minecraft:inventory")?.container?.addItem(new ItemStack("mkampf:kampfbuch"));
  spieler.sendMessage("§6⚔ Mittelalter-Kampf aktiv! §7Öffne das §eKampfbuch§7 (Rechtsklick) für alle Regeln.");
}));

// --- Schleifen -------------------------------------------------------------

world.afterEvents.worldLoad.subscribe(() => {
  system.runInterval(sicher("Anzeige", anzeigeSchleife), 2);
  system.runInterval(sicher("Posen", posenSchleife), 5);
  system.runInterval(sicher("Blutung", blutungsSchleife), 20);
  system.runInterval(sicher("Nebenhand", nebenhandSchleife), 5);
});
