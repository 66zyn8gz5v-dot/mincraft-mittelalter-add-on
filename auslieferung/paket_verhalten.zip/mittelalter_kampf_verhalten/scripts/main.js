// Einstiegspunkt des Add-ons „Mittelalter-Kampf“: verbindet alle Kampfmodule mit den Spielereignissen.
import {
  world, system, ItemStack, InputButton, ButtonState, EntitySwingSource,
} from "@minecraft/server";
import { vergessen, zustand } from "./kampf/zustand.js";
import { posenSchleife, naechsteHaltung } from "./kampf/haltung.js";
import { waffeIn } from "./kampf/werkzeuge.js";
import { schleichenGedrueckt, schleichenLosgelassen } from "./kampf/verteidigung.js";
import { bewegungsSchleife } from "./kampf/bewegung.js";
import {
  schwungBeginn, trefferVersuch, beiSchaden, blutungsSchleife, waffeGewechselt,
} from "./kampf/schaden.js";
import { nebenhandSchleife, nachWechsel, SPERRE } from "./kampf/nebenhand.js";
import { gegenstandBenutzt } from "./kampf/faehigkeiten.js";
import { anzeigeSchleife } from "./kampf/anzeige.js";
import { beiTod, beiVerlassen, duellTreffer, beiWiedereintritt, ringSchleife } from "./kampf/duell.js";
import { oeffneKampfbuch } from "./kampf/kampfbuch.js";
import { drehungAnwenden } from "./kampf/drehtest.js";
import {
  PUPPEN_ITEM, puppeAufstellen, puppeGetroffen, puppeAbbauen, puppenSchleife, puppenItemVerbrauchen,
} from "./kampf/puppe.js";
import { VERSION } from "./daten/waffen.js";
import { bogenSpannen, pfeilAbgeschossen } from "./kampf/bogen.js";
import { ruestungsSchleife } from "./kampf/ruestung.js";
import {
  BUCH, buchUmschalten, buchAufstellen, buchGeschlagen, buchBenutzt, buchSchleife, buecherAufraeumen,
} from "./kampf/buch.js";

/** Führt eine Funktion aus und meldet Fehler in der Konsole, ohne das Skript zu stoppen. */
function sicher(name, funktion) {
  return (...argumente) => {
    try {
      funktion(...argumente);
    } catch (fehler) {
      console.warn(`[Mittelalter-Kampf] Fehler in ${name}: ${fehler}`);
    }
  };
}

// --- Ereignisse ------------------------------------------------------------

world.afterEvents.playerSwingStart.subscribe(sicher("Schwung", (e) => {
  if (e.swingSource === EntitySwingSource.Attack) schwungBeginn(e.player);
}));

world.afterEvents.entityHitEntity.subscribe(sicher("Treffer", (e) => {
  if (e.damagingEntity?.typeId !== "minecraft:player") return;
  if (puppeAbbauen(e.damagingEntity, e.hitEntity)) return;
  if (e.hitEntity?.typeId === BUCH) {
    buchGeschlagen(e.damagingEntity, e.hitEntity);
    return;
  }
  trefferVersuch(e.damagingEntity, e.hitEntity);
}));

// Benutzen des aufgeschlagenen Buchs blättert weiter (mit Schleichen zurück).
world.afterEvents.playerInteractWithEntity.subscribe(sicher("Buch", (e) => {
  if (e.target?.typeId === BUCH) buchBenutzt(e.player, e.target);
}));

// Übungspuppe auf einen Block benutzt: Puppe aufstellen.
world.beforeEvents.playerInteractWithBlock.subscribe((e) => {
  if (e.itemStack?.typeId !== PUPPEN_ITEM || e.isFirstEvent === false) return;
  if (!e.block?.above?.()?.isAir) return;
  e.cancel = true;
  const { player, block } = e;
  system.run(sicher("Puppe aufstellen", () => {
    if (puppeAufstellen(player, block)) puppenItemVerbrauchen(player);
  }));
});

// Kampfbuch auf einen Block benutzt: als 3D-Buch auf einem Lesepult aufstellen.
world.beforeEvents.playerInteractWithBlock.subscribe((e) => {
  if (e.itemStack?.typeId !== "mkampf:kampfbuch" || e.player.isSneaking) return;
  if (e.isFirstEvent === false) return;
  // Nur wenn über dem Block Platz ist; sonst öffnet sich wie gewohnt das schwebende Buch.
  if (!e.block?.above?.()?.isAir) return;
  e.cancel = true;
  const { player, block } = e;
  system.run(sicher("Aufstellen", () => buchAufstellen(player, block)));
});

world.afterEvents.entityHurt.subscribe(sicher("Schaden", beiSchaden));
// Erst nach der Schadensberechnung: Duell-Runde entscheiden, bevor jemand stirbt.
world.afterEvents.entityHurt.subscribe(sicher("Duell", duellTreffer));
world.afterEvents.entityHurt.subscribe(sicher("Puppe", puppeGetroffen));

world.afterEvents.playerButtonInput.subscribe(
  sicher("Schleichen", (e) => schleichenGedrueckt(e.player)),
  { buttons: [InputButton.Sneak], state: ButtonState.Pressed },
);

world.afterEvents.playerButtonInput.subscribe(
  sicher("Schleichen los", (e) => schleichenLosgelassen(e.player)),
  { buttons: [InputButton.Sneak], state: ButtonState.Released },
);

// Schleichen + Springen wechselt die Haltung (Mitte → Hoch → Tief). Der Benutzen-Knopf der Waffe
// gehört ganz der Fähigkeit, damit ihre Abklingzeit auf dem Item nicht versehentlich startet.
world.afterEvents.playerButtonInput.subscribe(
  sicher("Haltung", (e) => {
    if (e.player.isSneaking && waffeIn(e.player)) naechsteHaltung(e.player);
  }),
  { buttons: [InputButton.Jump], state: ButtonState.Pressed },
);

world.afterEvents.itemUse.subscribe(sicher("Benutzen", (e) => {
  if (e.itemStack?.typeId === SPERRE) return;
  if (e.itemStack?.typeId === "mkampf:kampfbuch") {
    // Schleichen + Benutzen: Duell-Menü, sonst das große Buch auf- bzw. zuklappen.
    if (e.source.isSneaking) system.run(() => oeffneKampfbuch(e.source).catch(() => {}));
    else system.run(() => buchUmschalten(e.source)); // erst nach einem evtl. Aufstellen
    return;
  }
  gegenstandBenutzt(e.source, e.itemStack);
}));

// Langbogen: Ziehhaltung beim Spannen, schnellere Pfeile beim Abschuss.
world.afterEvents.itemStartUse.subscribe(sicher("Bogen", (e) => bogenSpannen(e.source, e.itemStack)));
world.afterEvents.entitySpawn.subscribe(sicher("Pfeil", (e) => pfeilAbgeschossen(e.entity)));

// Waffenwechsel: Aufladung zurücksetzen und Nebenhand-Sperre sofort anpassen.
world.afterEvents.playerHotbarSelectedSlotChange.subscribe(sicher("Wechsel", (e) => {
  waffeGewechselt(e.player);
  nachWechsel(e.player);
}));

world.afterEvents.entityDie.subscribe(sicher("Tod", beiTod));

world.afterEvents.playerLeave.subscribe(sicher("Verlassen", (e) => {
  beiVerlassen(e.playerId);
  vergessen(e.playerId);
}));

// Neue Spieler bekommen einmalig das Kampfbuch. Bei jedem Beitritt wird die geladene Version
// angezeigt und eine gewählte Drehtest-Variante wieder angewendet.
world.afterEvents.playerSpawn.subscribe(sicher("Beitritt", (e) => {
  const spieler = e.player;
  drehungAnwenden(spieler);
  // Nach Tod/Beitritt sind alle abgespielten Animationen weg: Posen und Lauf-Ebene neu starten.
  const z = zustand(spieler);
  z.haltungsSchluessel = "";
  z.laufWaffe = "";
  beiWiedereintritt(spieler);
  if (!e.initialSpawn) return;
  spieler.sendMessage(`§6⚔ Mittelalter-Kampf §fVerhalten v${VERSION} §7– der Name des Kampfbuchs ` +
    "zeigt die Bilder-Version (beide sollten gleich sein).");
  if (spieler.getDynamicProperty("mkampf:buch_erhalten")) return;
  spieler.setDynamicProperty("mkampf:buch_erhalten", true);
  spieler.getComponent("minecraft:inventory")?.container?.addItem(new ItemStack("mkampf:kampfbuch"));
  spieler.sendMessage("§6⚔ Mittelalter-Kampf aktiv! §7Benutze das §eKampfbuch§7 – es klappt vor dir auf. " +
    "Schlagen blättert weiter, Benutzen zurück.");
}));

// --- Schleifen -------------------------------------------------------------

world.afterEvents.worldLoad.subscribe(() => {
  buecherAufraeumen();
  system.runInterval(sicher("Buch", buchSchleife), 10);
  system.runInterval(sicher("Anzeige", anzeigeSchleife), 2);
  system.runInterval(sicher("Posen", posenSchleife), 5);
  system.runInterval(sicher("Blutung", blutungsSchleife), 20);
  system.runInterval(sicher("Nebenhand", nebenhandSchleife), 5);
  system.runInterval(sicher("Bewegung", bewegungsSchleife), 4);
  system.runInterval(sicher("Kampfring", ringSchleife), 10);
  system.runInterval(sicher("Puppen", puppenSchleife), 10);
  system.runInterval(sicher("Rüstung", ruestungsSchleife), 20);
});
