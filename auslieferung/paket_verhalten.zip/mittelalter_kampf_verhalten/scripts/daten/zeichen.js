// Automatisch erzeugt von tools/hud.py – eigene Zeichen aus font/glyph_E1.png.
export const ZEICHEN = {
  schwert: "\uE100",
  ausdauer: "\uE101",
  kraft: "\uE102",
  schild: "\uE103",
  stern: "\uE104",
  haltung: "\uE105",
  stueck: { weiss: "\uE110", leer: "\uE111", gruen: "\uE112", gelb: "\uE113", rot: "\uE114", orange: "\uE115", lila: "\uE116", blau: "\uE117", gold: "\uE118" },
};
