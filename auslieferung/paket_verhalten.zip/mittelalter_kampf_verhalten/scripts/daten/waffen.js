// Automatisch erzeugt von tools/generate.py – nicht von Hand bearbeiten.
// Werte jeder einzelnen Waffe (Stufe eingerechnet).
export const WAFFEN = {
 "mkampf:doppeldolche_eisen": {
  "art": "doppeldolche",
  "name": "Eiserne Doppeldolche",
  "stufe": "eisen",
  "schaden": 3,
  "cd": 0.35,
  "stil": "zwilling",
  "griff": "einhand",
  "kosten": 6,
  "faehigkeit": "schattenschritt",
  "fcd": 160
 },
 "mkampf:doppeldolche_gold": {
  "art": "doppeldolche",
  "name": "Goldene Doppeldolche",
  "stufe": "gold",
  "schaden": 2,
  "cd": 0.3,
  "stil": "zwilling",
  "griff": "einhand",
  "kosten": 6,
  "faehigkeit": "schattenschritt",
  "fcd": 160
 },
 "mkampf:doppeldolche_diamant": {
  "art": "doppeldolche",
  "name": "Diamantene Doppeldolche",
  "stufe": "diamant",
  "schaden": 4,
  "cd": 0.35,
  "stil": "zwilling",
  "griff": "einhand",
  "kosten": 6,
  "faehigkeit": "schattenschritt",
  "fcd": 160
 },
 "mkampf:doppeldolche_netherit": {
  "art": "doppeldolche",
  "name": "Netherit-Doppeldolche",
  "stufe": "netherit",
  "schaden": 5,
  "cd": 0.33,
  "stil": "zwilling",
  "griff": "einhand",
  "kosten": 6,
  "faehigkeit": "schattenschritt",
  "fcd": 160
 },
 "mkampf:langschwert_eisen": {
  "art": "langschwert",
  "name": "Eisernes Langschwert",
  "stufe": "eisen",
  "schaden": 5,
  "cd": 0.65,
  "stil": "hieb",
  "griff": "zweihand",
  "kosten": 10,
  "faehigkeit": "halbschwert",
  "fcd": 140
 },
 "mkampf:langschwert_gold": {
  "art": "langschwert",
  "name": "Goldenes Langschwert",
  "stufe": "gold",
  "schaden": 4,
  "cd": 0.55,
  "stil": "hieb",
  "griff": "zweihand",
  "kosten": 10,
  "faehigkeit": "halbschwert",
  "fcd": 140
 },
 "mkampf:langschwert_diamant": {
  "art": "langschwert",
  "name": "Diamantenes Langschwert",
  "stufe": "diamant",
  "schaden": 6,
  "cd": 0.65,
  "stil": "hieb",
  "griff": "zweihand",
  "kosten": 10,
  "faehigkeit": "halbschwert",
  "fcd": 140
 },
 "mkampf:langschwert_netherit": {
  "art": "langschwert",
  "name": "Netherit-Langschwert",
  "stufe": "netherit",
  "schaden": 7,
  "cd": 0.62,
  "stil": "hieb",
  "griff": "zweihand",
  "kosten": 10,
  "faehigkeit": "halbschwert",
  "fcd": 140
 },
 "mkampf:zweihaender_eisen": {
  "art": "zweihaender",
  "name": "Eiserner Zweihänder",
  "stufe": "eisen",
  "schaden": 8,
  "cd": 1.15,
  "stil": "hieb",
  "griff": "zweihand",
  "kosten": 18,
  "faehigkeit": "wirbelhieb",
  "fcd": 240
 },
 "mkampf:zweihaender_gold": {
  "art": "zweihaender",
  "name": "Goldener Zweihänder",
  "stufe": "gold",
  "schaden": 7,
  "cd": 0.98,
  "stil": "hieb",
  "griff": "zweihand",
  "kosten": 18,
  "faehigkeit": "wirbelhieb",
  "fcd": 240
 },
 "mkampf:zweihaender_diamant": {
  "art": "zweihaender",
  "name": "Diamantener Zweihänder",
  "stufe": "diamant",
  "schaden": 9,
  "cd": 1.15,
  "stil": "hieb",
  "griff": "zweihand",
  "kosten": 18,
  "faehigkeit": "wirbelhieb",
  "fcd": 240
 },
 "mkampf:zweihaender_netherit": {
  "art": "zweihaender",
  "name": "Netherit-Zweihänder",
  "stufe": "netherit",
  "schaden": 10,
  "cd": 1.09,
  "stil": "hieb",
  "griff": "zweihand",
  "kosten": 18,
  "faehigkeit": "wirbelhieb",
  "fcd": 240
 },
 "mkampf:rapier_eisen": {
  "art": "rapier",
  "name": "Eisernes Rapier",
  "stufe": "eisen",
  "schaden": 4,
  "cd": 0.45,
  "stil": "stoss",
  "griff": "einhand",
  "kosten": 7,
  "faehigkeit": "riposte",
  "fcd": 180
 },
 "mkampf:rapier_gold": {
  "art": "rapier",
  "name": "Goldenes Rapier",
  "stufe": "gold",
  "schaden": 3,
  "cd": 0.38,
  "stil": "stoss",
  "griff": "einhand",
  "kosten": 7,
  "faehigkeit": "riposte",
  "fcd": 180
 },
 "mkampf:rapier_diamant": {
  "art": "rapier",
  "name": "Diamantenes Rapier",
  "stufe": "diamant",
  "schaden": 5,
  "cd": 0.45,
  "stil": "stoss",
  "griff": "einhand",
  "kosten": 7,
  "faehigkeit": "riposte",
  "fcd": 180
 },
 "mkampf:rapier_netherit": {
  "art": "rapier",
  "name": "Netherit-Rapier",
  "stufe": "netherit",
  "schaden": 6,
  "cd": 0.43,
  "stil": "stoss",
  "griff": "einhand",
  "kosten": 7,
  "faehigkeit": "riposte",
  "fcd": 180
 },
 "mkampf:saebel_eisen": {
  "art": "saebel",
  "name": "Eiserner Säbel",
  "stufe": "eisen",
  "schaden": 5,
  "cd": 0.55,
  "stil": "hieb",
  "griff": "einhand",
  "kosten": 9,
  "faehigkeit": "klingenwirbel",
  "fcd": 200
 },
 "mkampf:saebel_gold": {
  "art": "saebel",
  "name": "Goldener Säbel",
  "stufe": "gold",
  "schaden": 4,
  "cd": 0.47,
  "stil": "hieb",
  "griff": "einhand",
  "kosten": 9,
  "faehigkeit": "klingenwirbel",
  "fcd": 200
 },
 "mkampf:saebel_diamant": {
  "art": "saebel",
  "name": "Diamantener Säbel",
  "stufe": "diamant",
  "schaden": 6,
  "cd": 0.55,
  "stil": "hieb",
  "griff": "einhand",
  "kosten": 9,
  "faehigkeit": "klingenwirbel",
  "fcd": 200
 },
 "mkampf:saebel_netherit": {
  "art": "saebel",
  "name": "Netherit-Säbel",
  "stufe": "netherit",
  "schaden": 7,
  "cd": 0.52,
  "stil": "hieb",
  "griff": "einhand",
  "kosten": 9,
  "faehigkeit": "klingenwirbel",
  "fcd": 200
 },
 "mkampf:streitaxt_eisen": {
  "art": "streitaxt",
  "name": "Eiserne Streitaxt",
  "stufe": "eisen",
  "schaden": 7,
  "cd": 1.0,
  "stil": "ueberkopf",
  "griff": "zweihand",
  "kosten": 15,
  "faehigkeit": "schildbrecher",
  "fcd": 200
 },
 "mkampf:streitaxt_gold": {
  "art": "streitaxt",
  "name": "Goldene Streitaxt",
  "stufe": "gold",
  "schaden": 6,
  "cd": 0.85,
  "stil": "ueberkopf",
  "griff": "zweihand",
  "kosten": 15,
  "faehigkeit": "schildbrecher",
  "fcd": 200
 },
 "mkampf:streitaxt_diamant": {
  "art": "streitaxt",
  "name": "Diamantene Streitaxt",
  "stufe": "diamant",
  "schaden": 8,
  "cd": 1.0,
  "stil": "ueberkopf",
  "griff": "zweihand",
  "kosten": 15,
  "faehigkeit": "schildbrecher",
  "fcd": 200
 },
 "mkampf:streitaxt_netherit": {
  "art": "streitaxt",
  "name": "Netherit-Streitaxt",
  "stufe": "netherit",
  "schaden": 9,
  "cd": 0.95,
  "stil": "ueberkopf",
  "griff": "zweihand",
  "kosten": 15,
  "faehigkeit": "schildbrecher",
  "fcd": 200
 },
 "mkampf:kriegshammer_eisen": {
  "art": "kriegshammer",
  "name": "Eiserner Kriegshammer",
  "stufe": "eisen",
  "schaden": 8,
  "cd": 1.3,
  "stil": "ueberkopf",
  "griff": "zweihand",
  "kosten": 20,
  "faehigkeit": "erdbeben",
  "fcd": 300
 },
 "mkampf:kriegshammer_gold": {
  "art": "kriegshammer",
  "name": "Goldener Kriegshammer",
  "stufe": "gold",
  "schaden": 7,
  "cd": 1.1,
  "stil": "ueberkopf",
  "griff": "zweihand",
  "kosten": 20,
  "faehigkeit": "erdbeben",
  "fcd": 300
 },
 "mkampf:kriegshammer_diamant": {
  "art": "kriegshammer",
  "name": "Diamantener Kriegshammer",
  "stufe": "diamant",
  "schaden": 9,
  "cd": 1.3,
  "stil": "ueberkopf",
  "griff": "zweihand",
  "kosten": 20,
  "faehigkeit": "erdbeben",
  "fcd": 300
 },
 "mkampf:kriegshammer_netherit": {
  "art": "kriegshammer",
  "name": "Netherit-Kriegshammer",
  "stufe": "netherit",
  "schaden": 10,
  "cd": 1.23,
  "stil": "ueberkopf",
  "griff": "zweihand",
  "kosten": 20,
  "faehigkeit": "erdbeben",
  "fcd": 300
 },
 "mkampf:streitkolben_eisen": {
  "art": "streitkolben",
  "name": "Eiserner Streitkolben",
  "stufe": "eisen",
  "schaden": 6,
  "cd": 0.85,
  "stil": "ueberkopf",
  "griff": "einhand",
  "kosten": 12,
  "faehigkeit": "schaedelspalter",
  "fcd": 220
 },
 "mkampf:streitkolben_gold": {
  "art": "streitkolben",
  "name": "Goldener Streitkolben",
  "stufe": "gold",
  "schaden": 5,
  "cd": 0.72,
  "stil": "ueberkopf",
  "griff": "einhand",
  "kosten": 12,
  "faehigkeit": "schaedelspalter",
  "fcd": 220
 },
 "mkampf:streitkolben_diamant": {
  "art": "streitkolben",
  "name": "Diamantener Streitkolben",
  "stufe": "diamant",
  "schaden": 7,
  "cd": 0.85,
  "stil": "ueberkopf",
  "griff": "einhand",
  "kosten": 12,
  "faehigkeit": "schaedelspalter",
  "fcd": 220
 },
 "mkampf:streitkolben_netherit": {
  "art": "streitkolben",
  "name": "Netherit-Streitkolben",
  "stufe": "netherit",
  "schaden": 8,
  "cd": 0.81,
  "stil": "ueberkopf",
  "griff": "einhand",
  "kosten": 12,
  "faehigkeit": "schaedelspalter",
  "fcd": 220
 },
 "mkampf:morgenstern_eisen": {
  "art": "morgenstern",
  "name": "Eiserner Morgenstern",
  "stufe": "eisen",
  "schaden": 7,
  "cd": 1.0,
  "stil": "hieb",
  "griff": "einhand",
  "kosten": 14,
  "faehigkeit": "kettenwurf",
  "fcd": 200
 },
 "mkampf:morgenstern_gold": {
  "art": "morgenstern",
  "name": "Goldener Morgenstern",
  "stufe": "gold",
  "schaden": 6,
  "cd": 0.85,
  "stil": "hieb",
  "griff": "einhand",
  "kosten": 14,
  "faehigkeit": "kettenwurf",
  "fcd": 200
 },
 "mkampf:morgenstern_diamant": {
  "art": "morgenstern",
  "name": "Diamantener Morgenstern",
  "stufe": "diamant",
  "schaden": 8,
  "cd": 1.0,
  "stil": "hieb",
  "griff": "einhand",
  "kosten": 14,
  "faehigkeit": "kettenwurf",
  "fcd": 200
 },
 "mkampf:morgenstern_netherit": {
  "art": "morgenstern",
  "name": "Netherit-Morgenstern",
  "stufe": "netherit",
  "schaden": 9,
  "cd": 0.95,
  "stil": "hieb",
  "griff": "einhand",
  "kosten": 14,
  "faehigkeit": "kettenwurf",
  "fcd": 200
 },
 "mkampf:hellebarde_eisen": {
  "art": "hellebarde",
  "name": "Eiserne Hellebarde",
  "stufe": "eisen",
  "schaden": 7,
  "cd": 1.1,
  "stil": "ueberkopf",
  "griff": "stange",
  "kosten": 16,
  "faehigkeit": "sichelzug",
  "fcd": 200
 },
 "mkampf:hellebarde_gold": {
  "art": "hellebarde",
  "name": "Goldene Hellebarde",
  "stufe": "gold",
  "schaden": 6,
  "cd": 0.94,
  "stil": "ueberkopf",
  "griff": "stange",
  "kosten": 16,
  "faehigkeit": "sichelzug",
  "fcd": 200
 },
 "mkampf:hellebarde_diamant": {
  "art": "hellebarde",
  "name": "Diamantene Hellebarde",
  "stufe": "diamant",
  "schaden": 8,
  "cd": 1.1,
  "stil": "ueberkopf",
  "griff": "stange",
  "kosten": 16,
  "faehigkeit": "sichelzug",
  "fcd": 200
 },
 "mkampf:hellebarde_netherit": {
  "art": "hellebarde",
  "name": "Netherit-Hellebarde",
  "stufe": "netherit",
  "schaden": 9,
  "cd": 1.04,
  "stil": "ueberkopf",
  "griff": "stange",
  "kosten": 16,
  "faehigkeit": "sichelzug",
  "fcd": 200
 },
 "mkampf:speer_eisen": {
  "art": "speer",
  "name": "Eiserner Speer",
  "stufe": "eisen",
  "schaden": 5,
  "cd": 0.8,
  "stil": "stoss",
  "griff": "stange",
  "kosten": 11,
  "faehigkeit": null,
  "fcd": 0
 },
 "mkampf:speer_gold": {
  "art": "speer",
  "name": "Goldener Speer",
  "stufe": "gold",
  "schaden": 4,
  "cd": 0.68,
  "stil": "stoss",
  "griff": "stange",
  "kosten": 11,
  "faehigkeit": null,
  "fcd": 0
 },
 "mkampf:speer_diamant": {
  "art": "speer",
  "name": "Diamantener Speer",
  "stufe": "diamant",
  "schaden": 6,
  "cd": 0.8,
  "stil": "stoss",
  "griff": "stange",
  "kosten": 11,
  "faehigkeit": null,
  "fcd": 0
 },
 "mkampf:speer_netherit": {
  "art": "speer",
  "name": "Netherit-Speer",
  "stufe": "netherit",
  "schaden": 7,
  "cd": 0.76,
  "stil": "stoss",
  "griff": "stange",
  "kosten": 11,
  "faehigkeit": null,
  "fcd": 0
 },
 "mkampf:kriegssense_eisen": {
  "art": "kriegssense",
  "name": "Eiserne Kriegssense",
  "stufe": "eisen",
  "schaden": 6,
  "cd": 0.95,
  "stil": "hieb",
  "griff": "stange",
  "kosten": 14,
  "faehigkeit": "seelenernte",
  "fcd": 220
 },
 "mkampf:kriegssense_gold": {
  "art": "kriegssense",
  "name": "Goldene Kriegssense",
  "stufe": "gold",
  "schaden": 5,
  "cd": 0.81,
  "stil": "hieb",
  "griff": "stange",
  "kosten": 14,
  "faehigkeit": "seelenernte",
  "fcd": 220
 },
 "mkampf:kriegssense_diamant": {
  "art": "kriegssense",
  "name": "Diamantene Kriegssense",
  "stufe": "diamant",
  "schaden": 7,
  "cd": 0.95,
  "stil": "hieb",
  "griff": "stange",
  "kosten": 14,
  "faehigkeit": "seelenernte",
  "fcd": 220
 },
 "mkampf:kriegssense_netherit": {
  "art": "kriegssense",
  "name": "Netherit-Kriegssense",
  "stufe": "netherit",
  "schaden": 8,
  "cd": 0.9,
  "stil": "hieb",
  "griff": "stange",
  "kosten": 14,
  "faehigkeit": "seelenernte",
  "fcd": 220
 }
};

// Beschreibung der 12 Waffenarten.
export const ARTEN = {
 "doppeldolche": {
  "name": "Doppeldolche",
  "passiv": "Blutung, Rückenstich x1,75, Beidhändig-Bonus",
  "griff": "einhand",
  "stil": "zwilling",
  "schadensart": "stich",
  "reichweite": 3.0,
  "faehigkeit": "schattenschritt",
  "faehigkeitName": "Schattenschritt",
  "faehigkeitText": "Blitzschneller Sprung nach vorn, der nächste Treffer zählt als Rückenstich.",
  "angriffe": [
   "Rechter Stich",
   "Linker Stich",
   "Aufwärtsschnitt",
   "Kreuzschnitt"
  ],
  "angriffDauer": [
   0.3,
   0.3,
   0.306,
   0.322
  ],
  "faehigkeitDauer": 0.5,
  "stellung": "Doppelte Wache",
  "schritte": [
   [
    0.35,
    0.4
   ],
   [
    0.35,
    0.4
   ],
   [
    0.25,
    0.4
   ],
   [
    0.5,
    0.45
   ]
  ],
  "gewicht": 1.1,
  "kraftDauer": 0.356,
  "kraftName": "Doppelstich",
  "kraftSchub": 1.2,
  "kraftZeit": 0.25,
  "sturmDauer": 0.342,
  "sturmName": "Sprungstich",
  "sturmSchub": 1.1,
  "blockName": "Kreuzblock",
  "ladenName": "Lauerstellung",
  "zweihaendig": false
 },
 "langschwert": {
  "name": "Langschwert",
  "passiv": "Kombo-Finisher +35 %, ausgewogen",
  "griff": "zweihand",
  "stil": "hieb",
  "schadensart": "schnitt",
  "reichweite": 3.3,
  "faehigkeit": "halbschwert",
  "faehigkeitName": "Halbschwert-Stoß",
  "faehigkeitText": "Ausfallschritt mit Stoß – der nächste Treffer verursacht +40 % Schaden.",
  "angriffe": [
   "Oberhau",
   "Unterhau",
   "Zornhau-Ort"
  ],
  "angriffDauer": [
   0.356,
   0.356,
   0.384
  ],
  "faehigkeitDauer": 0.6,
  "stellung": "Pflug",
  "schritte": [
   [
    0.35,
    0.5
   ],
   [
    0.25,
    0.5
   ],
   [
    0.8,
    0.45
   ]
  ],
  "gewicht": 1.0,
  "kraftDauer": 0.398,
  "kraftName": "Zornhau",
  "kraftSchub": 1.0,
  "kraftZeit": 0.3,
  "sturmDauer": 0.37,
  "sturmName": "Scheitelhau im Lauf",
  "sturmSchub": 1.0,
  "blockName": "Krone",
  "ladenName": "Zornhut",
  "zweihaendig": true
 },
 "zweihaender": {
  "name": "Zweihänder",
  "passiv": "Schwungschaden an Nahen Gegnern (40 %)",
  "griff": "zweihand",
  "stil": "hieb",
  "schadensart": "schnitt",
  "reichweite": 3.6,
  "faehigkeit": "wirbelhieb",
  "faehigkeitName": "Wirbelhieb",
  "faehigkeitText": "Drehangriff, trifft alle Gegner im Umkreis von 3 Blöcken.",
  "angriffe": [
   "Breiter Schwung",
   "Rückschwung",
   "Scheitelhieb"
  ],
  "angriffDauer": [
   0.44,
   0.44,
   0.468
  ],
  "faehigkeitDauer": 0.7,
  "stellung": "Vom Tag",
  "schritte": [
   [
    0.3,
    0.55
   ],
   [
    0.3,
    0.55
   ],
   [
    0.6,
    0.5
   ]
  ],
  "gewicht": 0.9,
  "kraftDauer": 0.454,
  "kraftName": "Wechselhau",
  "kraftSchub": 0.8,
  "kraftZeit": 0.35,
  "sturmDauer": 0.398,
  "sturmName": "Sturmhau",
  "sturmSchub": 0.9,
  "blockName": "Ochsendeckung",
  "ladenName": "Nebenhut",
  "zweihaendig": true
 },
 "rapier": {
  "name": "Rapier",
  "passiv": "Kritisch im Sprint/Fall x1,5, durchdringt Rüstung",
  "griff": "einhand",
  "stil": "stoss",
  "schadensart": "stich",
  "reichweite": 3.7,
  "faehigkeit": "riposte",
  "faehigkeitName": "Riposte",
  "faehigkeitText": "1 Sekunde Konterhaltung: der nächste Nahkampftreffer wird zurückgeworfen.",
  "angriffe": [
   "Stoß",
   "Finte",
   "Ausfall",
   "Rückschnitt"
  ],
  "angriffDauer": [
   0.314,
   0.342,
   0.356,
   0.314
  ],
  "faehigkeitDauer": 1.0,
  "stellung": "Terz",
  "schritte": [
   [
    0.6,
    0.45
   ],
   [
    0.5,
    0.5
   ],
   [
    1.1,
    0.45
   ],
   [
    0.2,
    0.5
   ]
  ],
  "gewicht": 1.07,
  "kraftDauer": 0.37,
  "kraftName": "Passata",
  "kraftSchub": 1.5,
  "kraftZeit": 0.2,
  "sturmDauer": 0.342,
  "sturmName": "Flèche",
  "sturmSchub": 1.3,
  "blockName": "Quart-Parade",
  "ladenName": "Gespannte Terz",
  "zweihaendig": false
 },
 "saebel": {
  "name": "Säbel",
  "passiv": "Blutung, Tempo-Rausch nach Treffer",
  "griff": "einhand",
  "stil": "hieb",
  "schadensart": "schnitt",
  "reichweite": 3.0,
  "faehigkeit": "klingenwirbel",
  "faehigkeitName": "Klingenwirbel",
  "faehigkeitText": "Drei schnelle, blutende Schnitte gegen das Ziel vor dir.",
  "angriffe": [
   "Kreisschnitt",
   "Rückhandschnitt",
   "Wirbelschnitt"
  ],
  "angriffDauer": [
   0.342,
   0.342,
   0.384
  ],
  "faehigkeitDauer": 0.9,
  "stellung": "Hohe Auslage",
  "schritte": [
   [
    0.4,
    0.5
   ],
   [
    0.3,
    0.5
   ],
   [
    0.5,
    0.5
   ]
  ],
  "gewicht": 1.05,
  "kraftDauer": 0.384,
  "kraftName": "Moulinet-Hieb",
  "kraftSchub": 0.9,
  "kraftZeit": 0.35,
  "sturmDauer": 0.356,
  "sturmName": "Reiterhieb",
  "sturmSchub": 1.0,
  "blockName": "Hängeparade",
  "ladenName": "Ausholen",
  "zweihaendig": false
 },
 "streitaxt": {
  "name": "Streitaxt",
  "passiv": "Bricht Schilde, schwere Treffer",
  "griff": "zweihand",
  "stil": "ueberkopf",
  "schadensart": "schnitt",
  "reichweite": 3.0,
  "faehigkeit": "schildbrecher",
  "faehigkeitName": "Schildbrecher",
  "faehigkeitText": "Wuchtiger Hieb, der den Schild des Gegners 5 Sekunden lang zerschlägt.",
  "angriffe": [
   "Schulterhieb",
   "Hakenhieb",
   "Spaltschlag"
  ],
  "angriffDauer": [
   0.412,
   0.412,
   0.454
  ],
  "faehigkeitDauer": 0.8,
  "stellung": "Schulterwacht",
  "schritte": [
   [
    0.3,
    0.55
   ],
   [
    0.2,
    0.55
   ],
   [
    0.5,
    0.55
   ]
  ],
  "gewicht": 0.94,
  "kraftDauer": 0.426,
  "kraftName": "Spalthieb",
  "kraftSchub": 0.7,
  "kraftZeit": 0.35,
  "sturmDauer": 0.384,
  "sturmName": "Laufhieb",
  "sturmSchub": 0.9,
  "blockName": "Stielwehr",
  "ladenName": "Hohe Ausholung",
  "zweihaendig": true
 },
 "kriegshammer": {
  "name": "Kriegshammer",
  "passiv": "Betäubt, starker Rückstoß, bricht Schilde",
  "griff": "zweihand",
  "stil": "ueberkopf",
  "schadensart": "wucht",
  "reichweite": 3.0,
  "faehigkeit": "erdbeben",
  "faehigkeitName": "Erdbeben",
  "faehigkeitText": "Bodenschlag: schleudert Gegner hoch und verlangsamt sie.",
  "angriffe": [
   "Seitenschlag",
   "Aufwärtsschlag",
   "Hammerfall"
  ],
  "angriffDauer": [
   0.468,
   0.468,
   0.496
  ],
  "faehigkeitDauer": 0.9,
  "stellung": "Hammerwacht",
  "schritte": [
   [
    0.2,
    0.6
   ],
   [
    0.2,
    0.6
   ],
   [
    0.45,
    0.6
   ]
  ],
  "gewicht": 0.86,
  "kraftDauer": 0.468,
  "kraftName": "Hammerschlag",
  "kraftSchub": 0.5,
  "kraftZeit": 0.4,
  "sturmDauer": 0.384,
  "sturmName": "Rammstoß",
  "sturmSchub": 1.0,
  "blockName": "Stielwehr",
  "ladenName": "Weite Ausholung",
  "zweihaendig": true
 },
 "streitkolben": {
  "name": "Streitkolben",
  "passiv": "Ignoriert Rüstung teilweise, Benommenheit",
  "griff": "einhand",
  "stil": "ueberkopf",
  "schadensart": "wucht",
  "reichweite": 3.0,
  "faehigkeit": "schaedelspalter",
  "faehigkeitName": "Schädelspalter",
  "faehigkeitText": "Der nächste Treffer betäubt und blendet den Gegner.",
  "angriffe": [
   "Oberhandschlag",
   "Rückhandschlag",
   "Zermalmen"
  ],
  "angriffDauer": [
   0.384,
   0.384,
   0.412
  ],
  "faehigkeitDauer": 1.0,
  "stellung": "Schildwacht",
  "schritte": [
   [
    0.3,
    0.55
   ],
   [
    0.25,
    0.55
   ],
   [
    0.45,
    0.55
   ]
  ],
  "gewicht": 0.98,
  "kraftDauer": 0.384,
  "kraftName": "Schmetterschlag",
  "kraftSchub": 0.8,
  "kraftZeit": 0.3,
  "sturmDauer": 0.356,
  "sturmName": "Überrennen",
  "sturmSchub": 1.0,
  "blockName": "Armdeckung",
  "ladenName": "Hohe Ausholung",
  "zweihaendig": false
 },
 "morgenstern": {
  "name": "Morgenstern",
  "passiv": "Umgeht Schildblock teilweise",
  "griff": "einhand",
  "stil": "hieb",
  "schadensart": "wucht",
  "reichweite": 3.0,
  "faehigkeit": "kettenwurf",
  "faehigkeitName": "Kettenwurf",
  "faehigkeitText": "Reißt ein Ziel bis 7 Blöcke Entfernung zu dir heran.",
  "angriffe": [
   "Kreisschlag",
   "Seitenwirbel",
   "Doppelkreis"
  ],
  "angriffDauer": [
   0.412,
   0.412,
   0.468
  ],
  "faehigkeitDauer": 0.8,
  "stellung": "Schwungwacht",
  "schritte": [
   [
    0.25,
    0.6
   ],
   [
    0.2,
    0.6
   ],
   [
    0.4,
    0.6
   ]
  ],
  "gewicht": 0.96,
  "kraftDauer": 0.426,
  "kraftName": "Wuchtkreis",
  "kraftSchub": 0.7,
  "kraftZeit": 0.35,
  "sturmDauer": 0.37,
  "sturmName": "Wirbelsturm",
  "sturmSchub": 1.0,
  "blockName": "Kettendeckung",
  "ladenName": "Kreisen",
  "zweihaendig": false
 },
 "hellebarde": {
  "name": "Hellebarde",
  "passiv": "Große Reichweite, Rückstoß",
  "griff": "stange",
  "stil": "ueberkopf",
  "schadensart": "schnitt",
  "reichweite": 4.3,
  "faehigkeit": "sichelzug",
  "faehigkeitName": "Sichelzug",
  "faehigkeitText": "Hakt das Ziel mit der Klinge und zieht es heran.",
  "angriffe": [
   "Langer Stoß",
   "Axthieb",
   "Hakenzug"
  ],
  "angriffDauer": [
   0.426,
   0.426,
   0.468
  ],
  "faehigkeitDauer": 0.8,
  "stellung": "Halbe Stange",
  "schritte": [
   [
    0.7,
    0.5
   ],
   [
    0.3,
    0.55
   ],
   [
    -0.5,
    0.7
   ]
  ],
  "gewicht": 0.94,
  "kraftDauer": 0.44,
  "kraftName": "Oberer Axthieb",
  "kraftSchub": 0.8,
  "kraftZeit": 0.35,
  "sturmDauer": 0.37,
  "sturmName": "Anlaufstoß",
  "sturmSchub": 1.2,
  "blockName": "Schaftwehr",
  "ladenName": "Obere Hut",
  "zweihaendig": true
 },
 "speer": {
  "name": "Speer",
  "passiv": "Ansturm (gedrückt halten), Sprint-Bonus",
  "griff": "stange",
  "stil": "stoss",
  "schadensart": "stich",
  "reichweite": 4.5,
  "faehigkeit": null,
  "faehigkeitName": "Ansturm",
  "faehigkeitText": "Rechtsklick gedrückt halten und anrennen – wie der Vanilla-Speer.",
  "angriffe": [
   "Tiefer Stoß",
   "Hoher Stoß",
   "Doppelstoß"
  ],
  "angriffDauer": [
   0.384,
   0.384,
   0.412
  ],
  "faehigkeitDauer": 0,
  "stellung": "Lanzenwacht",
  "schritte": [
   [
    0.8,
    0.5
   ],
   [
    0.6,
    0.5
   ],
   [
    0.9,
    0.6
   ]
  ],
  "gewicht": 0.97,
  "kraftDauer": 0.384,
  "kraftName": "Langer Stoß",
  "kraftSchub": 1.5,
  "kraftZeit": 0.2,
  "sturmDauer": 0.37,
  "sturmName": "Lanzenangriff",
  "sturmSchub": 1.4,
  "blockName": "Schaftwehr",
  "ladenName": "Gespannter Stoß",
  "zweihaendig": true
 },
 "kriegssense": {
  "name": "Kriegssense",
  "passiv": "Lebensraub 20 %",
  "griff": "stange",
  "stil": "hieb",
  "schadensart": "schnitt",
  "reichweite": 4.0,
  "faehigkeit": "seelenernte",
  "faehigkeitName": "Seelenernte",
  "faehigkeitText": "Weiter Sichelschwung vor dir, heilt dich pro Treffer.",
  "angriffe": [
   "Mähschnitt",
   "Erntehieb",
   "Todeskreis"
  ],
  "angriffDauer": [
   0.412,
   0.412,
   0.468
  ],
  "faehigkeitDauer": 0.8,
  "stellung": "Schnitterwacht",
  "schritte": [
   [
    0.4,
    0.55
   ],
   [
    0.3,
    0.55
   ],
   [
    0.6,
    0.5
   ]
  ],
  "gewicht": 0.95,
  "kraftDauer": 0.454,
  "kraftName": "Großer Mähschnitt",
  "kraftSchub": 0.6,
  "kraftZeit": 0.35,
  "sturmDauer": 0.384,
  "sturmName": "Sturmernte",
  "sturmSchub": 1.0,
  "blockName": "Schaftwehr",
  "ladenName": "Schnitterdrehung",
  "zweihaendig": true
 }
};

// Version des Add-ons (wird beim Betreten der Welt angezeigt).
export const VERSION = "1.33.0";

// Rüstungen: Wirkung je getragenem Teil auf Lauftempo und Ausdauererholung.
export const RUESTUNG = {"gambeson": {"tempo": 0.0, "erholung": 0.075, "gegen": {"schnitt": 0.95, "stich": 1.15, "wucht": 0.85}}, "schuppen": {"tempo": -0.005, "erholung": 0.0, "gegen": {"schnitt": 0.85, "stich": 1.05, "wucht": 1.0}}, "platte": {"tempo": -0.02, "erholung": -0.0625, "gegen": {"schnitt": 0.8, "stich": 1.0, "wucht": 1.2}}, "paladin": {"tempo": -0.015, "erholung": -0.03, "gegen": {"schnitt": 0.8, "stich": 0.9, "wucht": 1.1}}, "drachen": {"tempo": -0.01, "erholung": 0.0, "gegen": {"schnitt": 0.75, "stich": 0.85, "wucht": 1.05}}, "wolf": {"tempo": 0.005, "erholung": 0.03, "gegen": {"schnitt": 0.95, "stich": 1.0, "wucht": 0.9}}, "meuchler": {"tempo": 0.005, "erholung": 0.05, "gegen": {"schnitt": 1.0, "stich": 1.05, "wucht": 1.0}}, "held": {"tempo": -0.01, "erholung": 0.0, "gegen": {"schnitt": 0.85, "stich": 0.9, "wucht": 1.05}}};

// Rundschild (Buckler): Paradefenster-Faktor, Blockbonus, längere Betäubung.
export const BUCKLER = {"parade_faktor": 1.6, "block_bonus": 0.15, "betaeubung_bonus": 12};

export const BOGEN = {"tempo": 1.3, "haltbar": 420, "id": "mkampf:langbogen"};

// Anzahl der Drehtest-Varianten (siehe DREH_VARIANTEN in generate.py).
export const DREH_VARIANTEN = 8;

// Seitenzahl des aufklappbaren Kampfbuchs.
export const BUCH_SEITEN = 23;
